-- 005_indexes_triggers.sql
-- Índices e Triggers do ZapFlow

-- Índices para performance
CREATE INDEX idx_profiles_id ON profiles(id);
CREATE INDEX idx_memberships_company_id ON memberships(company_id);
CREATE INDEX idx_memberships_user_id ON memberships(user_id);
CREATE INDEX idx_leads_company_id ON leads(company_id);
CREATE INDEX idx_leads_status ON leads(status);
CREATE INDEX idx_leads_assigned_to ON leads(assigned_to);
CREATE INDEX idx_conversations_company_id ON conversations(company_id);
CREATE INDEX idx_conversations_status ON conversations(status);
CREATE INDEX idx_conversations_assigned_to ON conversations(assigned_to);
CREATE INDEX idx_messages_company_id ON messages(company_id);
CREATE INDEX idx_messages_conversation_id ON messages(conversation_id);
CREATE INDEX idx_tracking_links_company_id ON tracking_links(company_id);
CREATE INDEX idx_clicks_company_id ON clicks(company_id);
CREATE INDEX idx_clicks_tracking_link_id ON clicks(tracking_link_id);
CREATE INDEX idx_locations_company_id ON locations(company_id);

-- Índices para conversation_assignments
CREATE INDEX idx_conversation_assignments_conversation_id ON conversation_assignments(conversation_id);
CREATE INDEX idx_conversation_assignments_from_user_id ON conversation_assignments(from_user_id);
CREATE INDEX idx_conversation_assignments_to_user_id ON conversation_assignments(to_user_id);
CREATE INDEX idx_conversation_assignments_changed_by ON conversation_assignments(changed_by);

-- Índices compostos para consultas comuns
CREATE INDEX idx_leads_company_status ON leads(company_id, status);
CREATE INDEX idx_conversations_company_status ON conversations(company_id, status);
CREATE INDEX idx_messages_conversation_created ON messages(conversation_id, created_at);

-- Triggers para updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_companies_updated_at BEFORE UPDATE ON companies
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON profiles
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_memberships_updated_at BEFORE UPDATE ON memberships
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_leads_updated_at BEFORE UPDATE ON leads
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_conversations_updated_at BEFORE UPDATE ON conversations
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_tracking_links_updated_at BEFORE UPDATE ON tracking_links
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Trigger para incrementar contador de cliques
CREATE OR REPLACE FUNCTION increment_click_count()
RETURNS TRIGGER AS $$
BEGIN
  UPDATE tracking_links
  SET click_count = click_count + 1,
      updated_at = NOW()
  WHERE id = NEW.tracking_link_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER increment_tracking_link_clicks AFTER INSERT ON clicks
  FOR EACH ROW EXECUTE FUNCTION increment_click_count();

-- Trigger para atualizar last_message_at nas conversas
CREATE OR REPLACE FUNCTION update_conversation_last_message()
RETURNS TRIGGER AS $$
BEGIN
  UPDATE conversations
  SET last_message_at = NEW.created_at,
      updated_at = NOW()
  WHERE id = NEW.conversation_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_conversation_last_message_trigger AFTER INSERT ON messages
  FOR EACH ROW EXECUTE FUNCTION update_conversation_last_message();