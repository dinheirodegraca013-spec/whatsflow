-- 004_rls.sql
-- Políticas de Segurança (RLS) - Isolamento total por empresa

-- Limpar tabela users antiga se existir (compatibilidade)
DROP TABLE IF EXISTS users CASCADE;

-- Habilitar RLS em todas as tabelas
ALTER TABLE companies ENABLE ROW LEVEL SECURITY;
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE memberships ENABLE ROW LEVEL SECURITY;
ALTER TABLE leads ENABLE ROW LEVEL SECURITY;
ALTER TABLE conversations ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE tracking_links ENABLE ROW LEVEL SECURITY;
ALTER TABLE clicks ENABLE ROW LEVEL SECURITY;
ALTER TABLE locations ENABLE ROW LEVEL SECURITY;
ALTER TABLE conversation_assignments ENABLE ROW LEVEL SECURITY;
-- Políticas para companies
CREATE POLICY "Users can create companies" ON companies
  FOR INSERT WITH CHECK (
    auth.role() = 'authenticated'
  );

CREATE POLICY "Users can view companies they belong to" ON companies
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM memberships
      WHERE memberships.company_id = companies.id
      AND memberships.user_id = auth.uid()
      AND memberships.joined_at IS NOT NULL
    )
  );

CREATE POLICY "Only owners can update companies" ON companies
  FOR UPDATE USING (
    has_role(auth.uid(), companies.id, 'owner')
  );

CREATE POLICY "Only owners can delete companies" ON companies
  FOR DELETE USING (
    has_role(auth.uid(), companies.id, 'owner')
  );

-- Políticas para profiles
CREATE POLICY "Users can view their own profile" ON profiles
  FOR SELECT USING (
    id = auth.uid()
  );

CREATE POLICY "Users can update their own profile" ON profiles
  FOR UPDATE USING (
    id = auth.uid()
  );

CREATE POLICY "Users can insert their own profile" ON profiles
  FOR INSERT WITH CHECK (
    id = auth.uid()
  );

CREATE POLICY "Admins can view profiles in their company" ON profiles
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM memberships
      WHERE memberships.user_id = profiles.id
      AND memberships.company_id IN (
        SELECT company_id FROM memberships
        WHERE user_id = auth.uid() AND joined_at IS NOT NULL
      )
      AND memberships.joined_at IS NOT NULL
    )
  );

-- Políticas para memberships
CREATE POLICY "Users can create owner membership for their company" ON memberships
  FOR INSERT WITH CHECK (
    user_id = auth.uid()
    AND role = 'owner'
    AND joined_at IS NOT NULL
  );

CREATE POLICY "Users can view memberships in their company" ON memberships
  FOR SELECT USING (
    is_company_member(auth.uid(), company_id)
  );

CREATE POLICY "Admins can insert memberships" ON memberships
  FOR INSERT WITH CHECK (
    has_role(auth.uid(), company_id, 'admin') OR
    (NOT EXISTS (SELECT 1 FROM memberships WHERE user_id = auth.uid() AND joined_at IS NOT NULL) AND role = 'owner')
  );

CREATE POLICY "Admins can update memberships" ON memberships
  FOR UPDATE USING (
    has_role(auth.uid(), company_id, 'admin') OR has_role(auth.uid(), company_id, 'owner')
  );

CREATE POLICY "Owners and admins can delete memberships" ON memberships
  FOR DELETE USING (
    has_role(auth.uid(), company_id, 'admin') OR has_role(auth.uid(), company_id, 'owner')
  );

-- Políticas para leads
CREATE POLICY "Users can view leads in their company" ON leads
  FOR SELECT USING (
    is_company_member(auth.uid(), company_id)
  );

CREATE POLICY "Users can insert leads in their company" ON leads
  FOR INSERT WITH CHECK (
    is_company_member(auth.uid(), company_id)
  );

CREATE POLICY "Users can update leads in their company" ON leads
  FOR UPDATE USING (
    is_company_member(auth.uid(), company_id)
  );

CREATE POLICY "Admins can delete leads" ON leads
  FOR DELETE USING (
    has_role(auth.uid(), company_id, 'admin')
  );

-- Políticas para conversations
CREATE POLICY "Users can view conversations in their company" ON conversations
  FOR SELECT USING (
    is_company_member(auth.uid(), company_id)
  );

CREATE POLICY "Users can insert conversations in their company" ON conversations
  FOR INSERT WITH CHECK (
    is_company_member(auth.uid(), company_id)
  );

CREATE POLICY "Users can update conversations in their company" ON conversations
  FOR UPDATE USING (
    is_company_member(auth.uid(), company_id)
  );

CREATE POLICY "Admins can delete conversations" ON conversations
  FOR DELETE USING (
    has_role(auth.uid(), company_id, 'admin')
  );

-- Políticas para messages
CREATE POLICY "Users can view messages in their company" ON messages
  FOR SELECT USING (
    is_company_member(auth.uid(), company_id)
  );

CREATE POLICY "Users can insert messages in their company" ON messages
  FOR INSERT WITH CHECK (
    is_company_member(auth.uid(), company_id)
  );

CREATE POLICY "Users can update messages in their company" ON messages
  FOR UPDATE USING (
    is_company_member(auth.uid(), company_id)
  );

CREATE POLICY "Admins can delete messages" ON messages
  FOR DELETE USING (
    has_role(auth.uid(), company_id, 'admin')
  );

-- Políticas para tracking_links
CREATE POLICY "Users can view tracking links in their company" ON tracking_links
  FOR SELECT USING (
    is_company_member(auth.uid(), company_id)
  );

CREATE POLICY "Users can insert tracking links in their company" ON tracking_links
  FOR INSERT WITH CHECK (
    is_company_member(auth.uid(), company_id)
  );

CREATE POLICY "Users can update tracking links in their company" ON tracking_links
  FOR UPDATE USING (
    is_company_member(auth.uid(), company_id)
  );

CREATE POLICY "Admins can delete tracking links" ON tracking_links
  FOR DELETE USING (
    has_role(auth.uid(), company_id, 'admin')
  );

-- Políticas para clicks
CREATE POLICY "Users can view clicks in their company" ON clicks
  FOR SELECT USING (
    is_company_member(auth.uid(), company_id)
  );

CREATE POLICY "System can insert clicks" ON clicks
  FOR INSERT WITH CHECK (auth.role() = 'service_role');

CREATE POLICY "Users can update clicks in their company" ON clicks
  FOR UPDATE USING (
    is_company_member(auth.uid(), company_id)
  );

CREATE POLICY "Admins can delete clicks" ON clicks
  FOR DELETE USING (
    has_role(auth.uid(), company_id, 'admin')
  );

-- Políticas para locations
CREATE POLICY "Users can view locations in their company" ON locations
  FOR SELECT USING (
    is_company_member(auth.uid(), company_id)
  );

CREATE POLICY "Users can insert locations in their company" ON locations
  FOR INSERT WITH CHECK (
    is_company_member(auth.uid(), company_id)
  );

CREATE POLICY "Users can update locations in their company" ON locations
  FOR UPDATE USING (
    is_company_member(auth.uid(), company_id)
  );

CREATE POLICY "Admins can delete locations" ON locations
  FOR DELETE USING (
    has_role(auth.uid(), company_id, 'admin')
  );

-- Políticas para conversation_assignments
CREATE POLICY "Users can view conversation assignments in their company" ON conversation_assignments
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM conversations c
      WHERE c.id = conversation_assignments.conversation_id
      AND is_company_member(auth.uid(), c.company_id)
    )
  );

CREATE POLICY "Users can insert conversation assignments in their company" ON conversation_assignments
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM conversations c
      WHERE c.id = conversation_assignments.conversation_id
      AND is_company_member(auth.uid(), c.company_id)
    )
  );

CREATE POLICY "Admins can delete conversation assignments" ON conversation_assignments
  FOR DELETE USING (
    EXISTS (
      SELECT 1 FROM conversations c
      WHERE c.id = conversation_assignments.conversation_id
      AND has_role(auth.uid(), c.company_id, 'admin')
    )
  );