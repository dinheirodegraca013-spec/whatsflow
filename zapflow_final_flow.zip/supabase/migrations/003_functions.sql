-- 003_functions.sql
-- Funções auxiliares do ZapFlow

-- Verifica se usuário é membro da empresa
CREATE OR REPLACE FUNCTION is_company_member(user_id UUID, company_id UUID)
RETURNS BOOLEAN AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM memberships
    WHERE memberships.user_id = $1
    AND memberships.company_id = $2
    AND memberships.joined_at IS NOT NULL
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Verifica se usuário tem determinado papel na empresa
CREATE OR REPLACE FUNCTION has_role(user_id UUID, company_id UUID, required_role membership_role)
RETURNS BOOLEAN AS $$
DECLARE
  user_role membership_role;
BEGIN
  SELECT role INTO user_role
  FROM memberships
  WHERE memberships.user_id = $1
  AND memberships.company_id = $2
  AND memberships.joined_at IS NOT NULL;

  IF user_role IS NULL THEN
    RETURN FALSE;
  END IF;

  -- Hierarquia: owner > admin > member
  RETURN CASE
    WHEN required_role = 'member' THEN TRUE
    WHEN required_role = 'admin' THEN user_role IN ('owner', 'admin')
    WHEN required_role = 'owner' THEN user_role = 'owner'
    ELSE FALSE
  END;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Função para obter company_id do usuário atual (REMOVIDA - SaaS multi-tenant requer company_id explícito do frontend)