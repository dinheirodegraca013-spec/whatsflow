-- 001_enums.sql
-- Enums do sistema ZapFlow

-- Status dos leads no CRM
CREATE TYPE lead_status AS ENUM ('new', 'contacted', 'qualified', 'proposal', 'negotiation', 'won', 'lost');

-- Status das conversas no inbox
CREATE TYPE conversation_status AS ENUM ('active', 'closed', 'archived');

-- Tipos de mensagens
CREATE TYPE message_type AS ENUM ('text', 'image', 'video', 'audio', 'document', 'location', 'contact');

-- Papéis dos membros da empresa
CREATE TYPE membership_role AS ENUM ('owner', 'admin', 'member');

-- Status dos links de tracking
CREATE TYPE tracking_link_status AS ENUM ('active', 'inactive');

-- Tipos de eventos de clique
CREATE TYPE click_event_type AS ENUM ('page_view', 'form_submit', 'phone_click', 'whatsapp_click', 'email_click');