-- 006_auth_triggers.sql
-- Triggers e funções para autenticação e criação de empresa

-- Função para criar empresa automaticamente no primeiro signup
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
DECLARE
  company_name TEXT;
  company_slug TEXT;
  company_id UUID;
BEGIN
  -- Se não há company_id no metadata, criar uma nova empresa
  IF NEW.raw_user_meta_data->>'company_id' IS NULL THEN
    -- Usar nome da empresa do metadata ou nome do usuário como fallback
    company_name := COALESCE(NEW.raw_user_meta_data->>'company_name', split_part(NEW.email, '@', 1));
    company_slug := lower(regexp_replace(company_name, '[^a-zA-Z0-9]+', '-', 'g'));

    -- Garantir slug único
    WHILE EXISTS (SELECT 1 FROM companies WHERE slug = company_slug) LOOP
      company_slug := company_slug || '-' || floor(random() * 1000)::text;
    END LOOP;

    -- Criar empresa
    INSERT INTO companies (name, slug)
    VALUES (company_name, company_slug)
    RETURNING id INTO company_id;

    -- Inserir na tabela profiles com company_id
    INSERT INTO profiles (id, email, full_name)
    VALUES (NEW.id, NEW.email, NEW.raw_user_meta_data->>'full_name');

    -- Criar membership como owner
    INSERT INTO memberships (company_id, user_id, role, joined_at)
    VALUES (company_id, NEW.id, 'owner', NOW());

  ELSE
    -- Usar company_id existente do metadata
    company_id := (NEW.raw_user_meta_data->>'company_id')::UUID;

    -- Verificar se a empresa existe
    IF NOT EXISTS (SELECT 1 FROM companies WHERE id = company_id) THEN
      RAISE EXCEPTION 'Company not found';
    END IF;

    -- Inserir na tabela profiles
    INSERT INTO profiles (id, email, full_name)
    VALUES (NEW.id, NEW.email, NEW.raw_user_meta_data->>'full_name');

    -- Criar membership como member
    INSERT INTO memberships (company_id, user_id, role, joined_at)
    VALUES (company_id, NEW.id, 'member', NOW());
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger para executar após insert em auth.users
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();

-- Função para atualizar user profile quando auth.users é atualizado
CREATE OR REPLACE FUNCTION handle_user_update()
RETURNS TRIGGER AS $$
BEGIN
  UPDATE profiles
  SET
    email = NEW.email,
    full_name = COALESCE(NEW.raw_user_meta_data->>'full_name', profiles.full_name),
    updated_at = NOW()
  WHERE id = NEW.id;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger para atualizar profile quando auth.users muda
CREATE TRIGGER on_auth_user_updated
  AFTER UPDATE ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_user_update();

-- Função para deletar dados relacionados quando usuário é deletado
CREATE OR REPLACE FUNCTION handle_user_delete()
RETURNS TRIGGER AS $$
BEGIN
  -- O CASCADE nas foreign keys vai cuidar da maioria das deleções
  -- Aqui podemos adicionar lógica adicional se necessário
  RETURN OLD;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger para limpeza quando auth.users é deletado
CREATE TRIGGER on_auth_user_deleted
  AFTER DELETE ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_user_delete();