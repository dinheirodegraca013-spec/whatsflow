-- supabase/scripts/reset_dev.sql
-- DEV ONLY: Reset ZapFlow data without deleting auth.users.
-- Safe for local/dev. Do NOT run in production.
--
-- Usage (Supabase CLI):
--   supabase db reset
-- or run in SQL editor connected to local dev.

begin;

-- Disable triggers temporarily (optional)
-- set session_replication_role = replica;

-- Order matters due to FKs.
truncate table public.clicks restart identity cascade;
truncate table public.messages restart identity cascade;
truncate table public.conversation_assignments restart identity cascade;
truncate table public.conversations restart identity cascade;
truncate table public.leads restart identity cascade;
truncate table public.tracking_links restart identity cascade;
truncate table public.locations restart identity cascade;
truncate table public.memberships restart identity cascade;
truncate table public.companies restart identity cascade;

-- profiles are derived from auth.users; in dev it's OK to clear
truncate table public.profiles restart identity cascade;

-- set session_replication_role = origin;

commit;
