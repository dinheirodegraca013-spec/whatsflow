# ZapFlow - SaaS WhatsApp + CRM

Uma plataforma SaaS completa para gestão de WhatsApp e CRM, com arquitetura multi-tenant e isolamento completo de dados.

## 🚀 Funcionalidades

- **WhatsApp Inbox**: Gestão completa de conversas via WhatsApp Business API
- **CRM**: Gerenciamento de leads, contatos e oportunidades
- **Tracking**: Rastreamento de links e campanhas de marketing
- **Multi-tenant**: Isolamento completo por empresa com RLS
- **Dashboard**: Analytics e relatórios em tempo real

## 🛠️ Stack Tecnológica

- **Frontend**: React + TypeScript + Vite
- **UI**: Tailwind CSS + shadcn/ui
- **Backend**: Supabase (PostgreSQL + Auth + RLS)
- **State Management**: React Query + Context API
- **Build**: Vite + SWC

## 📦 Instalação

```bash
# Instalar dependências
npm install

# Executar em desenvolvimento
npm run dev

# Build para produção
npm run build
```

## 🔧 Configuração

1. Configure as variáveis de ambiente no arquivo `.env`:
```env
VITE_SUPABASE_URL=your_supabase_url
VITE_SUPABASE_PUBLISHABLE_KEY=your_supabase_key
```

2. Execute as migrações do banco de dados na pasta `supabase/migrations/`

## 📁 Estrutura do Projeto

```
src/
├── components/          # Componentes reutilizáveis
├── contexts/           # Context API (Auth, Company)
├── hooks/             # Hooks customizados
├── integrations/      # Integrações (Supabase)
├── pages/            # Páginas da aplicação
└── lib/              # Utilitários

supabase/
├── migrations/       # Migrações do banco
└── config.toml      # Configuração do Supabase
```

## 🔐 Autenticação e Autorização

- **Supabase Auth**: Autenticação completa com email/senha
- **Row Level Security**: Isolamento de dados por empresa
- **Role-based Access**: Controle de permissões (owner/admin/member)

## 🚀 Deploy

O projeto está configurado para deploy em qualquer plataforma que suporte Vite:

```bash
npm run build
# Deploy da pasta dist/
```

## 📝 Scripts Disponíveis

- `npm run dev` - Servidor de desenvolvimento
- `npm run build` - Build para produção
- `npm run preview` - Preview do build
- `npm run lint` - Verificação de código
- `npm run test` - Executar testes

## 🤝 Contribuição

1. Fork o projeto
2. Crie uma branch para sua feature (`git checkout -b feature/nova-feature`)
3. Commit suas mudanças (`git commit -m 'Adiciona nova feature'`)
4. Push para a branch (`git push origin feature/nova-feature`)
5. Abra um Pull Request

## 📄 Licença

Este projeto está sob a licença MIT.
