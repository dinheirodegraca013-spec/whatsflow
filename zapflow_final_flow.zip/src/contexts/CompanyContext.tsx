import React, { createContext, useContext, useEffect, useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { debugError, debugLog } from "@/lib/debug";
import type { Tables } from "@/integrations/supabase/types";

type Company = Tables<"companies">;
type Membership = Tables<"memberships">;

interface CompanyContextType {
  company: Company | null;
  companyId: string | null;
  role: Membership["role"] | null;
  memberships: Membership[];
  loading: boolean;
  setCompany: (company: Company | null) => void;
}

const CompanyContext = createContext<CompanyContextType | undefined>(undefined);

export function CompanyProvider({ children }: { children: React.ReactNode }) {
  const { user, loading: authLoading } = useAuth();
  const [company, setCompany] = useState<Company | null>(null);

  const membershipsQuery = useQuery({
    queryKey: ["memberships", user?.id],
    enabled: Boolean(user?.id),
    queryFn: async () => {
      if (!user?.id) return [] as Membership[];
      debugLog("CompanyContext", "memberships query start", { userId: user.id });

      const { data, error } = await supabase
        .from("memberships")
        .select("id,user_id,company_id,role,joined_at,created_at,invited_at,invited_by")
        .eq("user_id", user.id)
        .not("joined_at", "is", null);

      if (error) {
        debugError("CompanyContext", "memberships query error", error, { userId: user.id });
        throw error;
      }

      debugLog("CompanyContext", "memberships query done", {
        userId: user.id,
        membershipsLength: data?.length ?? 0,
      });

      debugLog("CompanyContext", "memberships loaded", { count: data?.length ?? 0 });

      return (data ?? []) as Membership[];
    },
    onSuccess: (data) => {
      setCompany((prev) => prev ?? (data as Company | null));
    },
    staleTime: 30_000,
    refetchOnWindowFocus: false,
  });

  const memberships = membershipsQuery.data ?? [];
  const membershipsLoading = membershipsQuery.isLoading;

  const activeCompanyId = company?.id ?? memberships[0]?.company_id ?? null;

  const companyQuery = useQuery({
    queryKey: ["company", activeCompanyId],
    enabled: Boolean(activeCompanyId),
    queryFn: async () => {
      if (!activeCompanyId) return null as Company | null;

      debugLog("CompanyContext", "company query start", { companyId: activeCompanyId });

      const { data, error } = await supabase
        .from("companies")
        .select("id,name,slug,domain,logo_url,settings,created_at,updated_at")
        .eq("id", activeCompanyId)
        .maybeSingle();

      if (error) {
        debugError("CompanyContext", "company query error", error, { companyId: activeCompanyId });
        throw error;
      }

      debugLog("CompanyContext", "company query done", {
        companyId: activeCompanyId,
        hasCompany: Boolean(data),
      });

      return data as Company | null;
    },
    onSuccess: (data) => {
      setCompany((prev) => prev ?? (data as Company | null));
    },
    staleTime: 30_000,
    refetchOnWindowFocus: false,
  });

  const currentMembership = memberships.find((m) => m.company_id === activeCompanyId) ?? null;
  const role = currentMembership?.role ?? null;

useEffect(() => {
  debugLog("CompanyContext", "state", {
    authLoading,
    membershipsLoading,
    companyLoading: companyQuery.isLoading,
    companyId: activeCompanyId,
    role,
    membershipsLength: memberships.length,
  });
}, [authLoading, membershipsLoading, companyQuery.isLoading, activeCompanyId, role, memberships.length]);


  const value = useMemo<CompanyContextType>(
    () => ({
      company: companyQuery.data ?? company,
      companyId: activeCompanyId,
      role,
      memberships,
      loading: authLoading || membershipsLoading || companyQuery.isLoading,
      setCompany,
    }),
    [activeCompanyId, authLoading, company, companyQuery.data, companyQuery.isLoading, memberships, membershipsLoading, role]
  );

  return <CompanyContext.Provider value={value}>{children}</CompanyContext.Provider>;
}

export function useCompany() {
  const ctx = useContext(CompanyContext);
  if (!ctx) throw new Error("useCompany must be used within a CompanyProvider");
  return ctx;
}
