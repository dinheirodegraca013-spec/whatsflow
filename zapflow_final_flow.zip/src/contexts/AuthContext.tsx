import React, { createContext, useContext, useEffect, useMemo, useState } from "react";
import type { Session, User } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";
import { debugError, debugLog } from "@/lib/debug";
import { useQueryClient } from "@tanstack/react-query";

type SignResult = { data: Session | null; error: unknown | null };

interface AuthContextType {
  user: User | null;
  session: Session | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<SignResult>;
  signUp: (
    email: string,
    password: string,
    metadata?: { full_name?: string; company_name?: string }
  ) => Promise<SignResult>;
  signOut: () => Promise<{ error: unknown | null }>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const queryClient = useQueryClient();

  const createCompanySetup = async (user: User) => {
    debugLog("AuthContext", "createCompanySetup called", { userId: user.id, companyName: (user.user_metadata as any)?.company_name ?? null });
    try {
      // Check if user already has company setup
      const { data: existingMemberships } = await supabase
        .from("memberships")
        .select("id")
        .eq("user_id", user.id);

      if (existingMemberships && existingMemberships.length > 0) {
        debugLog("AuthContext", "company setup already exists", { userId: user.id });
        return;
      }

      // Get company name from user metadata
      const companyName = user.user_metadata?.company_name;
      if (!companyName) {
        debugLog("AuthContext", "no company name in metadata", { userId: user.id });
        return;
      }

      debugLog("AuthContext", "creating company setup", { userId: user.id, companyName });

      const slug = companyName
        .toLowerCase()
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "")
        .replace(/[^a-z0-9]+/g, "-")
        .replace(/(^-|-$)+/g, "")
        .slice(0, 48);

      // Create company
      const { data: company, error: companyErr } = await supabase
        .from("companies")
        .insert({ name: companyName, slug })
        .select("id,name,slug,domain,logo_url,settings,created_at,updated_at")
        .single();

      if (companyErr) throw companyErr;

      // Create membership
      const { error: membershipErr } = await supabase.from("memberships").insert({
        company_id: company.id,
        user_id: user.id,
        role: "owner",
        joined_at: new Date().toISOString(),
      });

      if (membershipErr) throw membershipErr;

      // Create profile
      const { error: profileErr } = await supabase.from("profiles").insert({
        id: user.id,
        email: user.email,
        full_name: user.user_metadata?.full_name || null,
      });

      if (profileErr) throw profileErr;

      debugLog("AuthContext", "company setup complete", { userId: user.id, companyId: company.id });

      // Invalidate queries to refresh CompanyContext
      queryClient.invalidateQueries({ queryKey: ["memberships", user.id] });
      queryClient.invalidateQueries({ queryKey: ["company", company.id] });
    } catch (error) {
      debugError("AuthContext", "company setup error", error, { userId: user.id });
    }
  };

  useEffect(() => {
    let mounted = true;

    (async () => {
      const { data, error } = await supabase.auth.getSession();
      if (!mounted) return;

      if (error) {
        debugError("AuthContext", "getSession error", error);
      }

      setSession(data.session ?? null);
      setUser(data.session?.user ?? null);
      setLoading(false);

      debugLog("AuthContext", "getSession", {
        hasSession: Boolean(data.session),
        userId: data.session?.user?.id ?? null,
      });

      // If user just signed up and has a session, create company setup
      if (data.session?.user && !data.session.user.email_confirmed_at) {
        debugLog("AuthContext", "calling createCompanySetup on getSession");
        await createCompanySetup(data.session.user);
      }
    })();

    const { data: subscription } = supabase.auth.onAuthStateChange(async (event, newSession) => {
      setSession(newSession ?? null);
      setUser(newSession?.user ?? null);
      setLoading(false);

      debugLog("AuthContext", "onAuthStateChange", {
        event,
        hasSession: Boolean(newSession),
        userId: newSession?.user?.id ?? null,
      });

      // Create company setup when user confirms email or signs in
      if (newSession?.user && (event === 'SIGNED_IN' || event === 'TOKEN_REFRESHED')) {
        debugLog("AuthContext", "calling createCompanySetup", { event });
        await createCompanySetup(newSession.user);
      }
    });

    return () => {
      mounted = false;
      subscription.subscription.unsubscribe();
    };
  }, []);

  const signIn = async (email: string, password: string): Promise<SignResult> => {
    const { data, error } = await supabase.auth.signInWithPassword({ email, password });

    if (error) {
      debugError("AuthContext", "signIn error", error, { email });
      return { data: null, error };
    }

    // Invalidate and refetch company-related queries after successful login
    if (data.session?.user?.id) {
      queryClient.invalidateQueries({ queryKey: ["memberships", data.session.user.id] });
      queryClient.invalidateQueries({ queryKey: ["company"] });
      await queryClient.refetchQueries({ queryKey: ["memberships", data.session.user.id] });
    }

    debugLog("AuthContext", "signIn ok", {
      userId: data.session?.user?.id ?? null,
      hasSession: Boolean(data.session),
    });

    return { data: data.session ?? null, error: null };
  };

  const signUp = async (
    email: string,
    password: string,
    metadata?: { full_name?: string; company_name?: string }
  ): Promise<SignResult> => {
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: { data: metadata },
    });

    if (error) {
      debugError("AuthContext", "signUp error", error, { email });
      return { data: null, error };
    }

    debugLog("AuthContext", "signUp ok", {
      userId: data.session?.user?.id ?? null,
      hasSession: Boolean(data.session),
      needsEmailConfirmation: !data.session,
    });

    return { data: data.session ?? null, error: null };
  };

  const signOut = async () => {
    const { error } = await supabase.auth.signOut();
    if (error) debugError("AuthContext", "signOut error", error);
    else debugLog("AuthContext", "signOut ok");
    return { error: error ?? null };
  };

  const value = useMemo(
    () => ({
      user,
      session,
      loading,
      signIn,
      signUp,
      signOut,
    }),
    [user, session, loading]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within an AuthProvider");
  return ctx;
}
