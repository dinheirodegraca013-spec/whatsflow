import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import type { PostgrestError } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";
import { useCompany } from "@/contexts/CompanyContext";
import { useAuth } from "@/contexts/AuthContext";
import { debugError, debugLog } from "@/lib/debug";
import type { Tables } from "@/integrations/supabase/types";

type Lead = Tables<"leads">;
type Conversation = Tables<"conversations">;
type Message = Tables<"messages">;
type Membership = Tables<"memberships">;
type TrackingLink = Tables<"tracking_links">;

function logSupabaseError(scope: string, op: string, error: unknown, payload?: Record<string, unknown>) {
  const pg = error as PostgrestError | null;
  debugError(scope, op, error, {
    ...payload,
    message: pg?.message,
    details: pg?.details,
    hint: pg?.hint,
    code: (pg as any)?.code,
  });
}

export function useCompanyQuery<TData>(
  table: string,
  queryKey: unknown[],
  queryFn: (companyId: string) => Promise<TData>,
  options?: { enabled?: boolean }
) {
  const { companyId } = useCompany();

  return useQuery({
    queryKey: [table, companyId, ...queryKey],
    enabled: Boolean(companyId) && (options?.enabled ?? true),
    queryFn: async () => {
      if (!companyId) throw new Error("Company not loaded");
      debugLog("CompanyQuery", `query ${table}`, { companyId, queryKey });
      return queryFn(companyId);
    },
    staleTime: 10_000,
    refetchOnWindowFocus: false,
  });
}

/** Leads (CRM/Contacts) */
export function useLeads() {
  return useCompanyQuery<Lead[]>("leads", ["list"], async (companyId) => {
    const { data, error } = await supabase
      .from("leads")
      .select(
        "id,company_id,name,email,phone,status,value,source,campaign,notes,assigned_to,created_at,updated_at,utm_source,utm_medium,utm_campaign,utm_term,utm_content,created_by"
      )
      .eq("company_id", companyId)
      .order("created_at", { ascending: false })
      .limit(1000);  // Limit to prevent loading too many records

    if (error) {
      logSupabaseError("Leads", "select", error, { companyId });
      throw error;
    }
    return (data ?? []) as Lead[];
  });
}

export function useCreateLead() {
  const qc = useQueryClient();
  const { companyId } = useCompany();
  const { user } = useAuth();

  return useMutation({
    mutationFn: async (payload: Pick<Lead, "name"> & Partial<Omit<Lead, "id" | "created_at" | "updated_at">>) => {
      if (!companyId) throw new Error("Company not loaded");
      const insertPayload = {
        company_id: companyId,
        created_by: user?.id ?? null,
        status: "new",
        ...payload,
      };

      debugLog("Leads", "insert payload", { companyId, payload: { ...insertPayload, notes: payload.notes ? "(string)" : null } });

      const { data, error } = await supabase.from("leads").insert(insertPayload).select().single();
      if (error) {
        logSupabaseError("Leads", "insert", error, { companyId });
        throw error;
      }
      return data as Lead;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["leads"] });
      qc.invalidateQueries({ queryKey: ["dashboard"] });
    },
  });
}

export function useUpdateLead() {
  const qc = useQueryClient();
  const { companyId } = useCompany();

  return useMutation({
    mutationFn: async (args: { id: string; patch: Partial<Lead> }) => {
      if (!companyId) throw new Error("Company not loaded");

      debugLog("Leads", "update payload", { companyId, id: args.id, patch: args.patch });

      const { data, error } = await supabase
        .from("leads")
        .update({ ...args.patch, updated_at: new Date().toISOString() })
        .eq("id", args.id)
        .eq("company_id", companyId)
        .select()
        .single();

      if (error) {
        logSupabaseError("Leads", "update", error, { companyId, id: args.id });
        throw error;
      }
      return data as Lead;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["leads"] });
      qc.invalidateQueries({ queryKey: ["dashboard"] });
    },
  });
}

export function useDeleteLead() {
  const qc = useQueryClient();
  const { companyId } = useCompany();

  return useMutation({
    mutationFn: async (id: string) => {
      if (!companyId) throw new Error("Company not loaded");
      debugLog("Leads", "delete", { companyId, id });

      const { error } = await supabase.from("leads").delete().eq("id", id).eq("company_id", companyId);
      if (error) {
        logSupabaseError("Leads", "delete", error, { companyId, id });
        throw error;
      }
      return true;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["leads"] });
      qc.invalidateQueries({ queryKey: ["dashboard"] });
    },
  });
}

/** Inbox (conversations + messages) */
export function useConversations() {
  return useCompanyQuery<Conversation[]>("conversations", ["list"], async (companyId) => {
    const { data, error } = await supabase
      .from("conversations")
      .select("id,company_id,lead_id,status,assigned_to,last_message_at,created_at,updated_at")
      .eq("company_id", companyId)
      .order("last_message_at", { ascending: false, nullsFirst: false })
      .order("created_at", { ascending: false })
      .limit(500);  // Limit to prevent loading too many conversations

    if (error) {
      logSupabaseError("Conversations", "select", error, { companyId });
      throw error;
    }
    return (data ?? []) as Conversation[];
  });
}

export function useConversationMessages(conversationId: string | null) {
  return useQuery({
    queryKey: ["messages", conversationId],
    enabled: Boolean(conversationId),
    queryFn: async () => {
      if (!conversationId) return [] as Message[];
      const { data, error } = await supabase
        .from("messages")
        .select("id,company_id,conversation_id,type,content,is_from_me,created_at,metadata")
        .eq("conversation_id", conversationId)
        .order("created_at", { ascending: true });

      if (error) {
        logSupabaseError("Messages", "select", error, { conversationId });
        throw error;
      }
      return (data ?? []) as Message[];
    },
    staleTime: 2_000,
    refetchOnWindowFocus: false,
  });
}

export function useTakeConversation() {
  const qc = useQueryClient();
  const { companyId } = useCompany();
  const { user } = useAuth();

  return useMutation({
    mutationFn: async (conversationId: string) => {
      if (!companyId) throw new Error("Company not loaded");
      if (!user?.id) throw new Error("Not authenticated");

      debugLog("Conversations", "take", { companyId, conversationId, userId: user.id });

      const { data, error } = await supabase
        .from("conversations")
        .update({ assigned_to: user.id })
        .eq("id", conversationId)
        .eq("company_id", companyId)
        .select()
        .single();

      if (error) {
        logSupabaseError("Conversations", "take update", error, { companyId, conversationId });
        throw error;
      }

      // Create assignment record (no company_id column here)
      const { error: assignError } = await supabase.from("conversation_assignments").insert({
        conversation_id: conversationId,
        from_user_id: null,
        to_user_id: user.id,
        changed_by: user.id,
      });

      if (assignError) {
        logSupabaseError("ConversationAssignments", "insert", assignError, { conversationId });
      }

      return data as Conversation;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["conversations"] });
    },
  });
}

export function useTransferConversation() {
  const qc = useQueryClient();
  const { companyId } = useCompany();
  const { user } = useAuth();

  return useMutation({
    mutationFn: async (args: { conversationId: string; toUserId: string; currentAssignedTo: string | null }) => {
      if (!companyId) throw new Error("Company not loaded");
      if (!user?.id) throw new Error("Not authenticated");

      debugLog("Conversations", "transfer", { companyId, ...args, changedBy: user.id });

      const { data, error } = await supabase
        .from("conversations")
        .update({ assigned_to: args.toUserId })
        .eq("id", args.conversationId)
        .eq("company_id", companyId)
        .select()
        .single();

      if (error) {
        logSupabaseError("Conversations", "transfer update", error, { companyId, conversationId: args.conversationId });
        throw error;
      }

      const { error: assignError } = await supabase.from("conversation_assignments").insert({
        conversation_id: args.conversationId,
        from_user_id: args.currentAssignedTo,
        to_user_id: args.toUserId,
        changed_by: user.id,
      });

      if (assignError) {
        logSupabaseError("ConversationAssignments", "insert", assignError, { conversationId: args.conversationId });
      }

      return data as Conversation;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["conversations"] });
    },
  });
}

export function useCloseConversation() {
  const qc = useQueryClient();
  const { companyId } = useCompany();

  return useMutation({
    mutationFn: async (conversationId: string) => {
      if (!companyId) throw new Error("Company not loaded");
      debugLog("Conversations", "close", { companyId, conversationId });

      const { data, error } = await supabase
        .from("conversations")
        .update({ status: "closed" })
        .eq("id", conversationId)
        .eq("company_id", companyId)
        .select()
        .single();

      if (error) {
        logSupabaseError("Conversations", "close update", error, { companyId, conversationId });
        throw error;
      }
      return data as Conversation;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["conversations"] });
    },
  });
}

export function useSendMessage() {
  const qc = useQueryClient();
  const { companyId } = useCompany();
  const { user } = useAuth();

  return useMutation({
    mutationFn: async (args: { conversationId: string; content: string; type?: Message["type"] }) => {
      if (!companyId) throw new Error("Company not loaded");
      if (!user?.id) throw new Error("Not authenticated");

      const payload = {
        company_id: companyId,
        conversation_id: args.conversationId,
        content: args.content,
        type: args.type ?? "text",
        is_from_me: true,
        metadata: {},
      };

      debugLog("Messages", "insert payload", { companyId, conversationId: args.conversationId, type: payload.type });

      const { data, error } = await supabase.from("messages").insert(payload).select().single();
      if (error) {
        logSupabaseError("Messages", "insert", error, { companyId, conversationId: args.conversationId });
        throw error;
      }

      const { error: convErr } = await supabase
        .from("conversations")
        .update({ last_message_at: new Date().toISOString() })
        .eq("id", args.conversationId)
        .eq("company_id", companyId);

      if (convErr) logSupabaseError("Conversations", "update last_message_at", convErr, { companyId });

      return data as Message;
    },
    onSuccess: (_data, vars) => {
      qc.invalidateQueries({ queryKey: ["messages", vars.conversationId] });
      qc.invalidateQueries({ queryKey: ["conversations"] });
    },
  });
}

/** Members */
export function useCompanyMembers() {
  return useCompanyQuery<Membership[]>("memberships", ["company-members"], async (companyId) => {
    const { data, error } = await supabase
      .from("memberships")
      .select("id,company_id,user_id,role,joined_at,created_at,invited_at,invited_by")
      .eq("company_id", companyId)
      .not("joined_at", "is", null)
      .order("created_at", { ascending: true });

    if (error) {
      logSupabaseError("Members", "select", error, { companyId });
      throw error;
    }
    return (data ?? []) as Membership[];
  });
}

/** Tracking links */
export function useTrackingLinks() {
  return useCompanyQuery<TrackingLink[]>("tracking_links", ["list"], async (companyId) => {
    const { data, error } = await supabase
      .from("tracking_links")
      .select("id,company_id,name,slug,url,status,created_at,updated_at")
      .eq("company_id", companyId)
      .order("created_at", { ascending: false })
      .limit(200);  // Limit to prevent loading too many links

    if (error) {
      logSupabaseError("TrackingLinks", "select", error, { companyId });
      throw error;
    }
    return (data ?? []) as TrackingLink[];
  });
}

export function useCreateTrackingLink() {
  const qc = useQueryClient();
  const { companyId } = useCompany();

  return useMutation({
    mutationFn: async (payload: Pick<TrackingLink, "name" | "url" | "slug"> & Partial<TrackingLink>) => {
      if (!companyId) throw new Error("Company not loaded");
      const insertPayload = { company_id: companyId, status: "active", ...payload };

      debugLog("TrackingLinks", "insert payload", { companyId, payload: insertPayload });

      const { data, error } = await supabase.from("tracking_links").insert(insertPayload).select().single();
      if (error) {
        logSupabaseError("TrackingLinks", "insert", error, { companyId });
        throw error;
      }
      return data as TrackingLink;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["tracking_links"] });
    },
  });
}

export function useUpdateTrackingLink() {
  const qc = useQueryClient();
  const { companyId } = useCompany();

  return useMutation({
    mutationFn: async (args: { id: string; patch: Partial<TrackingLink> }) => {
      if (!companyId) throw new Error("Company not loaded");

      debugLog("TrackingLinks", "update payload", { companyId, ...args });

      const { data, error } = await supabase
        .from("tracking_links")
        .update({ ...args.patch, updated_at: new Date().toISOString() })
        .eq("id", args.id)
        .eq("company_id", companyId)
        .select()
        .single();

      if (error) {
        logSupabaseError("TrackingLinks", "update", error, { companyId, id: args.id });
        throw error;
      }
      return data as TrackingLink;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["tracking_links"] });
    },
  });
}

export function useDeleteTrackingLink() {
  const qc = useQueryClient();
  const { companyId } = useCompany();

  return useMutation({
    mutationFn: async (id: string) => {
      if (!companyId) throw new Error("Company not loaded");
      debugLog("TrackingLinks", "delete", { companyId, id });

      const { error } = await supabase.from("tracking_links").delete().eq("id", id).eq("company_id", companyId);
      if (error) {
        logSupabaseError("TrackingLinks", "delete", error, { companyId, id });
        throw error;
      }
      return true;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["tracking_links"] });
    },
  });
}


// Backward-compat alias
export const useMessages = useConversationMessages;
