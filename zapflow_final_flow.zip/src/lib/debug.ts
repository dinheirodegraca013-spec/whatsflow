/**
 * Debug logging (DEV only) gated by VITE_DEBUG_AUTH === "true".
 * Avoids logging secrets/tokens. Safe to keep in repo.
 */
const enabled =
  import.meta.env.DEV && String(import.meta.env.VITE_DEBUG_AUTH).toLowerCase() === "true";

type DebugPayload = Record<string, unknown>;

export function debugLog(scope: string, message: string, payload?: DebugPayload) {
  if (!enabled) return;
  // eslint-disable-next-line no-console
  console.log(`[${scope}] ${message}`, payload ?? {});
}

export function debugError(scope: string, message: string, error: unknown, payload?: DebugPayload) {
  if (!enabled) return;
  // eslint-disable-next-line no-console
  console.error(`[${scope}] ${message}`, { ...payload, error });
}
