import React from "react";
import { Navigate, useLocation } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { useCompany } from "@/contexts/CompanyContext";
import { debugLog } from "@/lib/debug";

interface ProtectedRouteProps {
  children: React.ReactNode;
  roles?: ("owner" | "admin" | "member")[];
  /**
   * Allow access even if there is no active company/membership (used for /onboarding).
   * Auth is still required.
   */
  allowWithoutCompany?: boolean;
}

export const ProtectedRoute: React.FC<ProtectedRouteProps> = ({
  children,
  roles = ["owner", "admin", "member"],
  allowWithoutCompany = false,
}) => {
  const location = useLocation();
  const { user, loading: authLoading } = useAuth();
  const { companyId, role, loading: companyLoading } = useCompany();

  const loading = authLoading || companyLoading;

  // Critical rule: never redirect while loading is true.
  if (loading) {
    debugLog("ProtectedRoute", "decision loading", { path: location.pathname });
    return (
      <div className="min-h-screen flex items-center justify-center text-sm text-muted-foreground">
        Carregando…
      </div>
    );
  }

  if (!user) {
    debugLog("ProtectedRoute", "decision redirect:/login", {
      path: location.pathname,
      reason: "no user/session",
    });
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  // Post-login decision:
  // - no active membership/company => onboarding (unless route explicitly allows without company)
  if (!companyId) {
    if (allowWithoutCompany) {
      debugLog("ProtectedRoute", "decision allow (no company) because allowWithoutCompany", {
        path: location.pathname,
        userId: user.id,
      });
      return <>{children}</>;
    }

    debugLog("ProtectedRoute", "decision redirect:/onboarding", {
      path: location.pathname,
      reason: "no active membership/company (memberships empty or joined_at NULL)",
      userId: user.id,
    });
    return <Navigate to="/onboarding" state={{ from: location }} replace />;
  }

  if (!role) {
    debugLog("ProtectedRoute", "decision redirect:/unauthorized", {
      path: location.pathname,
      reason: "no role",
      userId: user.id,
      companyId,
    });
    return <Navigate to="/unauthorized" replace />;
  }

  if (!roles.includes(role)) {
    debugLog("ProtectedRoute", "decision redirect:/unauthorized", {
      path: location.pathname,
      reason: "role insufficient",
      role,
      allowed: roles,
    });
    return <Navigate to="/unauthorized" replace />;
  }

  debugLog("ProtectedRoute", "decision allow", {
    path: location.pathname,
    userId: user.id,
    companyId,
    role,
  });

  return <>{children}</>;
};
