import React from "react";
import { Navigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";

/**
 * "/" entrypoint:
 * - unauthenticated -> /login
 * - authenticated -> /dashboard
 */
export function HomeRedirect() {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center text-sm text-muted-foreground">
        Carregando…
      </div>
    );
  }

  return <Navigate to={user ? "/dashboard" : "/login"} replace />;
}
