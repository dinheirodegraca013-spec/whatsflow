import React from "react";
import { useAuth } from "@/contexts/AuthContext";

/**
 * Blocks rendering until initial auth session is resolved, avoiding route "flashes".
 * NOTE: Does NOT redirect away from /login. This keeps /login always accessible for testing/debug.
 */
export function AuthGate({ children }: { children: React.ReactNode }) {
  const { loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center text-sm text-muted-foreground">
        Carregando…
      </div>
    );
  }

  return <>{children}</>;
}
