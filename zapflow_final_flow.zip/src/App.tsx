import React, { Suspense, lazy } from "react";
import { BrowserRouter, Navigate, Route, Routes } from "react-router-dom";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { AuthProvider } from "@/contexts/AuthContext";
import { CompanyProvider } from "@/contexts/CompanyContext";
import { ProtectedRoute } from "@/components/auth/ProtectedRoute";
import { AuthGate } from "@/components/auth/AuthGate";
import { HomeRedirect } from "@/components/auth/HomeRedirect";
import { AppLayout } from "@/components/layout/AppLayout";

const Dashboard = lazy(() => import("./pages/Dashboard"));
const Inbox = lazy(() => import("./pages/Inbox"));
const CRM = lazy(() => import("./pages/CRM"));
const Contacts = lazy(() => import("./pages/Contacts"));
const Sales = lazy(() => import("./pages/Sales"));
const Reports = lazy(() => import("./pages/Reports"));
const Links = lazy(() => import("./pages/Links"));
const Settings = lazy(() => import("./pages/Settings"));
const Onboarding = lazy(() => import("./pages/Onboarding"));
const Login = lazy(() => import("./pages/Login"));
const Unauthorized = lazy(() => import("./pages/Unauthorized"));
const NotFound = lazy(() => import("./pages/NotFound"));
const Logout = lazy(() => import("./pages/Logout"));

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      refetchOnWindowFocus: false,
      staleTime: 10_000,
    },
  },
});

function PageFallback() {
  return (
    <div className="min-h-screen flex items-center justify-center text-sm text-muted-foreground">
      Carregando…
    </div>
  );
}

const App = () => (
  <QueryClientProvider client={queryClient}>
    <AuthProvider>
      <CompanyProvider>
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <AuthGate>
              <Suspense fallback={<PageFallback />}>
                <Routes>
                  <Route path="/" element={<HomeRedirect />} />

                  <Route path="/login" element={<Login />} />

                  <Route path="/logout" element={<Logout />} />

                  <Route
                    path="/onboarding"
                    element={
                      <ProtectedRoute allowWithoutCompany>
                        <Onboarding />
                      </ProtectedRoute>
                    }
                  />

                  <Route element={<AppLayout />}>
                    <Route
                      path="/dashboard"
                      element={
                        <ProtectedRoute>
                          <Dashboard />
                        </ProtectedRoute>
                      }
                    />
                    <Route
                      path="/inbox"
                      element={
                        <ProtectedRoute>
                          <Inbox />
                        </ProtectedRoute>
                      }
                    />
                    <Route
                      path="/crm"
                      element={
                        <ProtectedRoute>
                          <CRM />
                        </ProtectedRoute>
                      }
                    />
                    <Route
                      path="/contacts"
                      element={
                        <ProtectedRoute>
                          <Contacts />
                        </ProtectedRoute>
                      }
                    />
                    <Route
                      path="/sales"
                      element={
                        <ProtectedRoute>
                          <Sales />
                        </ProtectedRoute>
                      }
                    />
                    <Route
                      path="/reports"
                      element={
                        <ProtectedRoute roles={["owner", "admin"]}>
                          <Reports />
                        </ProtectedRoute>
                      }
                    />
                    <Route
                      path="/links"
                      element={
                        <ProtectedRoute>
                          <Links />
                        </ProtectedRoute>
                      }
                    />
                    <Route
                      path="/settings"
                      element={
                        <ProtectedRoute roles={["owner", "admin"]}>
                          <Settings />
                        </ProtectedRoute>
                      }
                    />
                  </Route>

                  <Route path="/unauthorized" element={<Unauthorized />} />
                  <Route path="*" element={<NotFound />} />
                </Routes>
              </Suspense>
            </AuthGate>
          </BrowserRouter>
        </TooltipProvider>
      </CompanyProvider>
    </AuthProvider>
  </QueryClientProvider>
);

export default App;
