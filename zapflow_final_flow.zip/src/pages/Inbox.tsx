import { useState, useEffect } from "react";
import { Header } from "@/components/layout/Header";
import {
  Search,
  Filter,
  MoreVertical,
  Send,
  Paperclip,
  Smile,
  Phone,
  Video,
  User,
  Clock,
  Tag,
  ArrowRight,
  CheckCheck,
  Circle,
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Textarea } from "@/components/ui/textarea";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { cn } from "@/lib/utils";
import { debugError } from "@/lib/debug";
import {
  useConversations,
  useMessages,
  useCompanyMembers,
  useTakeConversation,
  useTransferConversation,
  useCloseConversation,
  useSendMessage,
} from "@/hooks/use-company-queries";
import { supabase } from "@/integrations/supabase/client";
import { useQueryClient } from "@tanstack/react-query";

export default function Inbox() {
  const [selectedConversation, setSelectedConversation] = useState<any>(null);
  const [messageText, setMessageText] = useState("");
  const [filter, setFilter] = useState<"all" | "waiting" | "active" | "resolved">("all");

  // Hooks for data fetching
  const { data: conversations = [], isLoading: conversationsLoading } = useConversations();
  const { data: companyMembers = [] } = useCompanyMembers();

  // Mutations
  const takeConversation = useTakeConversation();
  const transferConversation = useTransferConversation();
  const closeConversation = useCloseConversation();
  const sendMessage = useSendMessage();

  const queryClient = useQueryClient();

  // Set first conversation as selected when conversations load
  useEffect(() => {
    if (conversations.length > 0 && !selectedConversation) {
      setSelectedConversation(conversations[0]);
    }
  }, [conversations, selectedConversation]);

  // Messages for selected conversation
  const { data: messages = [] } = useMessages(selectedConversation?.id);

  // Real-time subscriptions
  useEffect(() => {
    if (!selectedConversation) return;

    const channel = supabase
      .channel(`conversation-${selectedConversation.id}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'messages',
          filter: `conversation_id=eq.${selectedConversation.id}`,
        },
        (payload) => {
          queryClient.invalidateQueries({ queryKey: ['messages', selectedConversation.id] });
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'conversations',
          filter: `id=eq.${selectedConversation.id}`,
        },
        (payload) => {
          queryClient.invalidateQueries({ queryKey: ['conversations'] });
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [selectedConversation, queryClient]);

  const filteredConversations = useMemo(() => {
    return conversations.filter((conv: any) => {
      if (filter === "all") return true;
      if (filter === "waiting") return !conv.assigned_to;
      if (filter === "active") return conv.assigned_to && conv.status === 'active';
      if (filter === "resolved") return conv.status === 'closed';
      return true;
    });
  }, [conversations, filter]);

  const handleTakeConversation = async (conversationId: string) => {
    try {
      await takeConversation.mutateAsync(conversationId);
    } catch (error) {
      debugError("Inbox", "take conversation error", error);
    }
  };

  const handleTransferConversation = async (conversationId: string, toUserId: string) => {
    try {
      await transferConversation.mutateAsync({ conversationId, toUserId });
    } catch (error) {
      debugError("Inbox", "transfer conversation error", error);
    }
  };

  const handleCloseConversation = async (conversationId: string) => {
    try {
      await closeConversation.mutateAsync(conversationId);
    } catch (error) {
      debugError("Inbox", "close conversation error", error);
    }
  };

  const handleSendMessage = async () => {
    if (!selectedConversation || !messageText.trim()) return;

    try {
      await sendMessage.mutateAsync({
        conversationId: selectedConversation.id,
        content: messageText.trim(),
      });
      setMessageText("");
    } catch (error) {
      debugError("Inbox", "send message error", error);
    }
  };

  const getStatusBadge = (status: string, assignedTo: string | null) => {
    if (!assignedTo) return <Badge variant="secondary">Na fila</Badge>;
    if (status === 'active') return <Badge variant="default">Em atendimento</Badge>;
    if (status === 'closed') return <Badge variant="outline">Resolvido</Badge>;
    return <Badge variant="secondary">{status}</Badge>;
  };

  const getTimeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));

    if (diffInMinutes < 1) return 'Agora';
    if (diffInMinutes < 60) return `${diffInMinutes}min`;
    if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)}h`;
    return `${Math.floor(diffInMinutes / 1440)}d`;
  };

  if (conversationsLoading) {
    return (
      <div className="flex flex-col h-full">
        <Header title="Inbox" subtitle="Carregando conversas..." />
        <div className="flex-1 flex items-center justify-center">
          <div className="text-muted-foreground">Carregando...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      <Header
        title="Inbox"
        subtitle={`${conversations.filter((c: any) => !c.assigned_to).length} conversas aguardando atendimento`}
      />

      <div className="flex-1 flex overflow-hidden">
        {/* Conversations List */}
        <div className="w-80 border-r border-border flex flex-col bg-card">
          {/* Filters */}
          <div className="p-4 border-b border-border space-y-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Buscar conversas..."
                className="pl-9 bg-muted/50 border-0"
              />
            </div>
            <div className="flex gap-2">
              <Button
                variant={filter === "all" ? "default" : "outline"}
                size="sm"
                onClick={() => setFilter("all")}
                className="flex-1"
              >
                Todas
              </Button>
              <Button
                variant={filter === "waiting" ? "default" : "outline"}
                size="sm"
                onClick={() => setFilter("waiting")}
                className="flex-1"
              >
                Fila
                <Badge variant="secondary" className="ml-1 h-5 px-1.5">
                  {conversations.filter((c: any) => !c.assigned_to).length}
                </Badge>
              </Button>
              <Button
                variant={filter === "active" ? "default" : "outline"}
                size="sm"
                onClick={() => setFilter("active")}
                className="flex-1"
              >
                Minhas
              </Button>
            </div>
          </div>

          {/* Conversation List */}
          <ScrollArea className="flex-1">
            {filteredConversations.map((conv: any) => (
              <div
                key={conv.id}
                onClick={() => setSelectedConversation(conv)}
                className={cn(
                  "inbox-item",
                  selectedConversation?.id === conv.id && "active",
                  !conv.assigned_to && "unread"
                )}
              >
                <div className="relative">
                  <Avatar className="h-11 w-11">
                    <AvatarImage src="" />
                    <AvatarFallback className="bg-primary/10 text-primary text-sm">
                      {conv.contact_name?.charAt(0) || conv.contact_phone?.slice(-2) || '?'}
                    </AvatarFallback>
                  </Avatar>
                  {!conv.assigned_to && (
                    <span className="absolute -top-0.5 -right-0.5 h-3 w-3 rounded-full bg-warning border-2 border-card" />
                  )}
                  {conv.assigned_to && conv.status === 'active' && (
                    <span className="absolute -top-0.5 -right-0.5 h-3 w-3 rounded-full bg-success border-2 border-card" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2">
                    <span
                      className={cn(
                        "font-medium text-sm truncate",
                        !conv.assigned_to && "font-semibold"
                      )}
                    >
                      {conv.contact_name || conv.contact_phone || 'Contato'}
                    </span>
                    <span className="text-xs text-muted-foreground flex-shrink-0">
                      {getTimeAgo(conv.last_message_at || conv.created_at)}
                    </span>
                  </div>
                  <p className="text-sm text-muted-foreground truncate mt-0.5">
                    {conv.last_message || 'Nova conversa'}
                  </p>
                  <div className="flex items-center gap-2 mt-1.5">
                    <span className="text-xs text-muted-foreground">{conv.source || 'WhatsApp'}</span>
                    {conv.assigned_to && (
                      <span className="text-xs text-primary">
                        • {companyMembers.find(m => m.user_id === conv.assigned_to)?.profiles?.full_name || 'Atendente'}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </ScrollArea>
        </div>

        {/* Chat Area */}
        <div className="flex-1 flex flex-col">
          {/* Chat Header */}
          <div className="h-16 px-6 border-b border-border flex items-center justify-between bg-card">
            <div className="flex items-center gap-3">
              <Avatar className="h-10 w-10">
                <AvatarImage src="" />
                <AvatarFallback className="bg-primary/10 text-primary">
                  {selectedConversation?.contact_name?.charAt(0) || selectedConversation?.contact_phone?.slice(-2) || '?'}
                </AvatarFallback>
              </Avatar>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-semibold">
                    {selectedConversation?.contact_name || selectedConversation?.contact_phone || 'Contato'}
                  </h3>
                  {getStatusBadge(selectedConversation?.status, selectedConversation?.assigned_to)}
                </div>
                <p className="text-sm text-muted-foreground">
                  {selectedConversation?.contact_phone} • {selectedConversation?.source || 'WhatsApp'}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="icon">
                <Phone className="h-4 w-4" />
              </Button>
              <Button variant="outline" size="icon">
                <Video className="h-4 w-4" />
              </Button>
              <Button variant="outline" size="icon">
                <User className="h-4 w-4" />
              </Button>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="icon">
                    <MoreVertical className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  {!selectedConversation?.assigned_to && (
                    <DropdownMenuItem onClick={() => handleTakeConversation(selectedConversation.id)}>
                      <ArrowRight className="h-4 w-4 mr-2" />
                      Pegar conversa
                    </DropdownMenuItem>
                  )}
                  {selectedConversation?.assigned_to && (
                    <>
                      <DropdownMenuItem>
                        <ArrowRight className="h-4 w-4 mr-2" />
                        Transferir conversa
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => handleCloseConversation(selectedConversation.id)}>
                        <CheckCheck className="h-4 w-4 mr-2" />
                        Encerrar conversa
                      </DropdownMenuItem>
                    </>
                  )}
                  <DropdownMenuItem>
                    <Tag className="h-4 w-4 mr-2" />
                    Adicionar tag
                  </DropdownMenuItem>
                  <DropdownMenuItem>
                    <Clock className="h-4 w-4 mr-2" />
                    Agendar lembrete
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>

          {/* Messages */}
          <ScrollArea className="flex-1 p-6">
            <div className="space-y-4 max-w-3xl mx-auto">
              {messages.map((msg: any) => (
                <div
                  key={msg.id}
                  className={cn(
                    "flex",
                    msg.is_from_me ? "justify-end" : "justify-start"
                  )}
                >
                  <div
                    className={cn(
                      "chat-bubble",
                      msg.is_from_me ? "outgoing" : "incoming"
                    )}
                  >
                    <p className="whitespace-pre-wrap">{msg.content}</p>
                    <div
                      className={cn(
                        "flex items-center gap-1 mt-1",
                        msg.is_from_me ? "justify-end" : "justify-start"
                      )}
                    >
                      <span
                        className={cn(
                          "text-xs",
                          msg.is_from_me
                            ? "text-primary-foreground/70"
                            : "text-muted-foreground"
                        )}
                      >
                        {new Date(msg.created_at).toLocaleTimeString('pt-BR', {
                          hour: '2-digit',
                          minute: '2-digit'
                        })}
                      </span>
                      {msg.is_from_me && (
                        <CheckCheck
                          className={cn(
                            "h-3.5 w-3.5",
                            "text-primary-foreground"
                          )}
                        />
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>

          {/* Message Input */}
          <div className="p-4 border-t border-border bg-card">
            <div className="flex items-end gap-3 max-w-3xl mx-auto">
              <div className="flex gap-2">
                <Button variant="ghost" size="icon" className="text-muted-foreground">
                  <Paperclip className="h-5 w-5" />
                </Button>
                <Button variant="ghost" size="icon" className="text-muted-foreground">
                  <Smile className="h-5 w-5" />
                </Button>
              </div>
              <Textarea
                value={messageText}
                onChange={(e) => setMessageText(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    handleSendMessage();
                  }
                }}
                placeholder="Digite sua mensagem..."
                className="min-h-[44px] max-h-32 resize-none"
                rows={1}
              />
              <Button
                size="icon"
                className="h-11 w-11"
                onClick={handleSendMessage}
                disabled={!messageText.trim() || sendMessage.isPending}
              >
                <Send className="h-5 w-5" />
              </Button>
            </div>
          </div>
        </div>

        {/* Right Sidebar - Contact Details */}
        <div className="w-72 border-l border-border bg-card hidden xl:flex flex-col">
          <div className="p-4 border-b border-border">
            <h3 className="font-semibold text-sm">Detalhes do Contato</h3>
          </div>
          <ScrollArea className="flex-1 p-4">
            <div className="space-y-6">
              {/* Contact Info */}
              <div className="text-center">
                <Avatar className="h-20 w-20 mx-auto">
                  <AvatarImage src="" />
                  <AvatarFallback className="bg-primary/10 text-primary text-2xl">
                    {selectedConversation?.contact_name?.charAt(0) || selectedConversation?.contact_phone?.slice(-2) || '?'}
                  </AvatarFallback>
                </Avatar>
                <h4 className="font-semibold mt-3">
                  {selectedConversation?.contact_name || selectedConversation?.contact_phone || 'Contato'}
                </h4>
                <p className="text-sm text-muted-foreground">
                  {selectedConversation?.contact_phone}
                </p>
              </div>

              {/* Quick Info */}
              <div className="space-y-3">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Origem</span>
                  <span className="font-medium">{selectedConversation?.source || 'WhatsApp'}</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Status</span>
                  {getStatusBadge(selectedConversation?.status, selectedConversation?.assigned_to)}
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Primeiro contato</span>
                  <span className="font-medium">
                    {selectedConversation?.created_at ? new Date(selectedConversation.created_at).toLocaleDateString('pt-BR') : 'N/A'}
                  </span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Mensagens</span>
                  <span className="font-medium">{messages.length}</span>
                </div>
              </div>

              {/* Team */}
              <div>
                <h5 className="text-sm font-medium mb-2">Transferir para</h5>
                <div className="space-y-2">
                  {companyMembers.map((member: any) => (
                    <button
                      key={member.user_id}
                      onClick={() => selectedConversation && handleTransferConversation(selectedConversation.id, member.user_id)}
                      className="w-full flex items-center gap-3 p-2 rounded-lg hover:bg-muted transition-colors"
                    >
                      <div className="relative">
                        <Avatar className="h-8 w-8">
                          <AvatarFallback className="bg-primary/10 text-primary text-xs">
                            {member.profiles?.full_name?.charAt(0) || member.profiles?.email?.charAt(0) || '?'}
                          </AvatarFallback>
                        </Avatar>
                        <Circle className="absolute -bottom-0.5 -right-0.5 h-3 w-3 fill-current text-success" />
                      </div>
                      <div className="flex-1 text-left">
                        <p className="text-sm font-medium">{member.profiles?.full_name || member.profiles?.email || 'Usuário'}</p>
                        <p className="text-xs text-muted-foreground capitalize">
                          {member.role === 'admin' ? 'Administrador' : member.role === 'agent' ? 'Atendente' : member.role}
                        </p>
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Actions */}
              <div className="space-y-2">
                <Button variant="outline" className="w-full justify-start">
                  <User className="h-4 w-4 mr-2" />
                  Ver perfil completo
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Tag className="h-4 w-4 mr-2" />
                  Converter em lead
                </Button>
              </div>
            </div>
          </ScrollArea>
        </div>
      </div>
    </div>
  );
}