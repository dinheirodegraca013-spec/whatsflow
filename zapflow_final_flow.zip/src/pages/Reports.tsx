import { useMemo } from "react";
import { Header } from "@/components/layout/Header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useCompany } from "@/contexts/CompanyContext";
import { supabase } from "@/integrations/supabase/client";
import { useQuery } from "@tanstack/react-query";
import { debugError, debugLog } from "@/lib/debug";

export default function Reports() {
  const { companyId } = useCompany();

  const clicksQuery = useQuery({
    queryKey: ["reports", companyId, "clicks"],
    enabled: Boolean(companyId),
    queryFn: async () => {
      if (!companyId) throw new Error("Company not loaded");
      debugLog("Reports", "clicks query start", { companyId });

      const since = new Date();
      since.setDate(since.getDate() - 30);

      const { data, error } = await supabase
        .from("clicks")
        .select("id,event_type,created_at")
        .eq("company_id", companyId)
        .gte("created_at", since.toISOString());

      if (error) {
        debugError("Reports", "clicks query error", error, { companyId });
        throw error;
      }
      debugLog("Reports", "clicks query done", { companyId, count: data?.length ?? 0 });
      return data ?? [];
    },
    staleTime: 10_000,
    refetchOnWindowFocus: false,
  });

  const byType = useMemo(() => {
    const rows = clicksQuery.data ?? [];
    const map = new Map<string, number>();
    for (const r of rows) map.set(r.event_type, (map.get(r.event_type) ?? 0) + 1);
    return Array.from(map.entries()).map(([k, v]) => ({ type: k, count: v })).sort((a, b) => b.count - a.count);
  }, [clicksQuery.data]);

  return (
    <div className="space-y-8">
      <Header title="Relatórios" description="Eventos e métricas (últimos 30 dias)" />

      {clicksQuery.isLoading ? (
        <div className="text-sm text-muted-foreground">Carregando…</div>
      ) : (clicksQuery.data ?? []).length === 0 ? (
        <Card>
          <CardContent className="p-8 text-center text-sm text-muted-foreground">
            Nenhum dado ainda. Quando houver cliques, eles aparecerão aqui.
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Clicks por tipo</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {byType.map((r) => (
              <div key={r.type} className="flex items-center justify-between rounded-lg bg-muted/50 p-3">
                <div className="text-sm font-medium">{r.type}</div>
                <div className="text-sm text-muted-foreground">{r.count}</div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
