import { useMemo } from "react";
import { Header } from "@/components/layout/Header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useCompany } from "@/contexts/CompanyContext";
import { supabase } from "@/integrations/supabase/client";
import { useQuery } from "@tanstack/react-query";
import { debugError, debugLog } from "@/lib/debug";
import {
  MessageSquare,
  Users,
  DollarSign,
  TrendingUp,
  ArrowUpRight,
  ArrowDownRight,
} from "lucide-react";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import type { Tables } from "@/integrations/supabase/types";

type Lead = Tables<"leads">;
type Conversation = Tables<"conversations">;
type Click = Tables<"clicks">;

type Kpi = {
  leads: number;
  activeConversations: number;
  revenueWon: number;
  clicks: number;
};

function startOfDayISO(d: Date) {
  const dt = new Date(d);
  dt.setHours(0, 0, 0, 0);
  return dt.toISOString();
}

export default function Dashboard() {
  const { companyId } = useCompany();

  const kpisQuery = useQuery({
    queryKey: ["dashboard", companyId, "kpis"],
    enabled: Boolean(companyId),
    queryFn: async () => {
      if (!companyId) throw new Error("Company not loaded");
      debugLog("Dashboard", "kpis query start", { companyId });

      const since = new Date();
      since.setDate(since.getDate() - 30);

      const [leadsRes, convRes, clicksRes] = await Promise.all([
        supabase
          .from("leads")
          .select("id,status,value", { count: "exact" })
          .eq("company_id", companyId)
          .gte("created_at", startOfDayISO(since)),
        supabase
          .from("conversations")
          .select("id,status", { count: "exact" })
          .eq("company_id", companyId)
          .gte("created_at", startOfDayISO(since)),
        supabase
          .from("clicks")
          .select("id", { count: "exact" })
          .eq("company_id", companyId)
          .gte("created_at", startOfDayISO(since)),
      ]);

      if (leadsRes.error) throw leadsRes.error;
      if (convRes.error) throw convRes.error;
      if (clicksRes.error) throw clicksRes.error;

      const leads = leadsRes.count ?? 0;
      const activeConversations =
        (convRes.data ?? []).filter((c) => c.status === "active").length;
      const clicks = clicksRes.count ?? 0;

      const revenueWon = (leadsRes.data ?? [])
        .filter((l) => l.status === "won")
        .reduce((sum, l) => sum + (l.value ?? 0), 0);

      const result: Kpi = { leads, activeConversations, revenueWon, clicks };

      debugLog("Dashboard", "kpis query done", result);
      return result;
    },
    staleTime: 10_000,
    refetchOnWindowFocus: false,
  });

  const leadsQuery = useQuery({
    queryKey: ["dashboard", companyId, "leads-30d"],
    enabled: Boolean(companyId),
    queryFn: async () => {
      if (!companyId) throw new Error("Company not loaded");
      const since = new Date();
      since.setDate(since.getDate() - 30);

      const { data, error } = await supabase
        .from("leads")
        .select("id,name,source,status,value,created_at")
        .eq("company_id", companyId)
        .gte("created_at", startOfDayISO(since))
        .order("created_at", { ascending: true });

      if (error) throw error;
      return (data ?? []) as Pick<Lead, "id" | "name" | "source" | "status" | "value" | "created_at">[];
    },
  });

  const conversationsQuery = useQuery({
    queryKey: ["dashboard", companyId, "conversations-30d"],
    enabled: Boolean(companyId),
    queryFn: async () => {
      if (!companyId) throw new Error("Company not loaded");
      const since = new Date();
      since.setDate(since.getDate() - 30);

      const { data, error } = await supabase
        .from("conversations")
        .select("id,assigned_to,status,created_at")
        .eq("company_id", companyId)
        .gte("created_at", startOfDayISO(since));

      if (error) throw error;
      return (data ?? []) as Pick<Conversation, "id" | "assigned_to" | "status" | "created_at">[];
    },
  });

  const clicksQuery = useQuery({
    queryKey: ["dashboard", companyId, "clicks-30d"],
    enabled: Boolean(companyId),
    queryFn: async () => {
      if (!companyId) throw new Error("Company not loaded");
      const since = new Date();
      since.setDate(since.getDate() - 30);

      const { data, error } = await supabase
        .from("clicks")
        .select("id,event_type,created_at")
        .eq("company_id", companyId)
        .gte("created_at", startOfDayISO(since));

      if (error) throw error;
      return (data ?? []) as Pick<Click, "id" | "event_type" | "created_at">[];
    },
  });

  const chartData = useMemo(() => {
    const leads = leadsQuery.data ?? [];
    const byDay = new Map<string, { day: string; leads: number; won: number }>();

    for (const l of leads) {
      const day = new Date(l.created_at).toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit" });
      const cur = byDay.get(day) ?? { day, leads: 0, won: 0 };
      cur.leads += 1;
      if (l.status === "won") cur.won += 1;
      byDay.set(day, cur);
    }

    return Array.from(byDay.values());
  }, [leadsQuery.data]);

  const channelData = useMemo(() => {
    const leads = leadsQuery.data ?? [];
    const bySource = new Map<string, number>();
    for (const l of leads) {
      const key = l.source ?? "Sem origem";
      bySource.set(key, (bySource.get(key) ?? 0) + 1);
    }
    return Array.from(bySource.entries())
      .map(([name, value]) => ({ name, value }))
      .sort((a, b) => b.value - a.value)
      .slice(0, 8);
  }, [leadsQuery.data]);

  const recentLeads = useMemo(() => {
    const leads = (leadsQuery.data ?? []).slice().reverse();
    return leads.slice(0, 5);
  }, [leadsQuery.data]);

  const topAttendants = useMemo(() => {
    const convs = conversationsQuery.data ?? [];
    const byUser = new Map<string, number>();
    for (const c of convs) {
      if (!c.assigned_to) continue;
      byUser.set(c.assigned_to, (byUser.get(c.assigned_to) ?? 0) + 1);
    }
    return Array.from(byUser.entries())
      .map(([userId, count]) => ({ userId, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 5);
  }, [conversationsQuery.data]);

  const kpis = kpisQuery.data ?? { leads: 0, activeConversations: 0, revenueWon: 0, clicks: 0 };

  const anyError = kpisQuery.error || leadsQuery.error || conversationsQuery.error || clicksQuery.error;
  if (anyError) {
    debugError("Dashboard", "query error", anyError);
  }

  return (
    <div className="space-y-8">
      <Header title="Dashboard" description="Visão geral do seu negócio" />

      {/* KPIs */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between space-x-2">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Leads (30 dias)</p>
                <p className="text-2xl font-bold">{kpis.leads}</p>
              </div>
              <div className="p-3 bg-primary/10 rounded-full">
                <Users className="h-6 w-6 text-primary" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between space-x-2">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Conversas Ativas</p>
                <p className="text-2xl font-bold">{kpis.activeConversations}</p>
              </div>
              <div className="p-3 bg-success/10 rounded-full">
                <MessageSquare className="h-6 w-6 text-success" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between space-x-2">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Receita (Won)</p>
                <p className="text-2xl font-bold">
                  {kpis.revenueWon.toLocaleString("pt-BR", { style: "currency", currency: "BRL" })}
                </p>
              </div>
              <div className="p-3 bg-warning/10 rounded-full">
                <DollarSign className="h-6 w-6 text-warning" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between space-x-2">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Clicks (30 dias)</p>
                <p className="text-2xl font-bold">{kpis.clicks}</p>
              </div>
              <div className="p-3 bg-primary/10 rounded-full">
                <TrendingUp className="h-6 w-6 text-primary" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-base font-semibold">Leads por dia (30 dias)</CardTitle>
          </CardHeader>
          <CardContent>
            {chartData.length === 0 ? (
              <div className="text-sm text-muted-foreground">
                Nenhum dado ainda. Comece criando o primeiro lead.
              </div>
            ) : (
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={chartData}>
                    <XAxis dataKey="day" fontSize={12} tickLine={false} axisLine={false} />
                    <YAxis fontSize={12} tickLine={false} axisLine={false} />
                    <Tooltip />
                    <Area type="monotone" dataKey="leads" strokeWidth={2} />
                    <Area type="monotone" dataKey="won" strokeWidth={2} />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base font-semibold">Leads por canal</CardTitle>
          </CardHeader>
          <CardContent>
            {channelData.length === 0 ? (
              <div className="text-sm text-muted-foreground">
                Nenhum dado ainda. Comece criando o primeiro lead.
              </div>
            ) : (
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={channelData}>
                    <XAxis dataKey="name" fontSize={12} tickLine={false} axisLine={false} />
                    <YAxis fontSize={12} tickLine={false} axisLine={false} />
                    <Tooltip />
                    <Bar dataKey="value" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Lists */}
      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-base font-semibold">Leads recentes</CardTitle>
          </CardHeader>
          <CardContent>
            {recentLeads.length === 0 ? (
              <div className="text-sm text-muted-foreground">
                Nenhum dado ainda. Comece criando o primeiro lead.
              </div>
            ) : (
              <div className="space-y-3">
                {recentLeads.map((lead) => (
                  <div key={lead.id} className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                    <div>
                      <p className="font-medium">{lead.name}</p>
                      <p className="text-sm text-muted-foreground">
                        {lead.source ?? "Sem origem"} • {new Date(lead.created_at).toLocaleDateString("pt-BR")}
                      </p>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      {lead.status === "won" ? (
                        <ArrowUpRight className="h-4 w-4 text-success" />
                      ) : lead.status === "lost" ? (
                        <ArrowDownRight className="h-4 w-4 text-destructive" />
                      ) : null}
                      <span className="capitalize">{lead.status}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base font-semibold">Atendentes (conversas atribuídas)</CardTitle>
          </CardHeader>
          <CardContent>
            {topAttendants.length === 0 ? (
              <div className="text-sm text-muted-foreground">
                Nenhum dado ainda. Quando você atribuir conversas, aparecerá aqui.
              </div>
            ) : (
              <div className="space-y-3">
                {topAttendants.map((item) => (
                  <div key={item.userId} className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                    <div>
                      <p className="font-medium">Usuário</p>
                      <p className="text-xs text-muted-foreground">{item.userId}</p>
                    </div>
                    <div className="text-sm font-medium">{item.count}</div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
