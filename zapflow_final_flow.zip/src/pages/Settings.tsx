import { useMemo, useState } from "react";
import { Header } from "@/components/layout/Header";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useCompany } from "@/contexts/CompanyContext";
import { supabase } from "@/integrations/supabase/client";
import { useCompanyMembers } from "@/hooks/use-company-queries";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { debugError, debugLog } from "@/lib/debug";

type Role = "owner" | "admin" | "member";

export default function Settings() {
  const { toast } = useToast();
  const qc = useQueryClient();
  const { company, companyId, role: myRole, setCompany } = useCompany();
  const membersQuery = useCompanyMembers();

  const [companyName, setCompanyName] = useState(company?.name ?? "");
  const [savingCompany, setSavingCompany] = useState(false);

  const userIds = useMemo(() => (membersQuery.data ?? []).map((m) => m.user_id), [membersQuery.data]);

  const profilesQuery = useQuery({
    queryKey: ["profiles", companyId, userIds.join(",")],
    enabled: Boolean(companyId) && userIds.length > 0,
    queryFn: async () => {
      debugLog("Settings", "profiles query start", { companyId, count: userIds.length });
      const { data, error } = await supabase
        .from("profiles")
        .select("id,email,full_name,avatar_url,phone")
        .in("id", userIds);

      if (error) {
        debugError("Settings", "profiles query error", error, { companyId });
        throw error;
      }
      return data ?? [];
    },
    staleTime: 30_000,
    refetchOnWindowFocus: false,
  });

  const profileById = useMemo(() => {
    const map = new Map<string, any>();
    for (const p of profilesQuery.data ?? []) map.set(p.id, p);
    return map;
  }, [profilesQuery.data]);

  const canManageMembers = myRole === "owner" || myRole === "admin";

  const saveCompany = async () => {
    if (!companyId) return;
    try {
      setSavingCompany(true);
      debugLog("Settings", "company update payload", { companyId, name: companyName });
      const { data, error } = await supabase
        .from("companies")
        .update({ name: companyName, updated_at: new Date().toISOString() })
        .eq("id", companyId)
        .select()
        .single();

      if (error) throw error;
      setCompany(data);
      toast({ title: "Empresa atualizada" });
    } catch (e: any) {
      toast({ title: "Erro ao salvar", description: e?.message ?? "Tente novamente", variant: "destructive" });
    } finally {
      setSavingCompany(false);
    }
  };

  const updateMemberRole = async (membershipId: string, newRole: Role) => {
    if (!companyId) return;
    try {
      debugLog("Settings", "membership update role", { companyId, membershipId, newRole });

      const { error } = await supabase
        .from("memberships")
        .update({ role: newRole })
        .eq("id", membershipId)
        .eq("company_id", companyId);

      if (error) throw error;

      qc.invalidateQueries({ queryKey: ["memberships"] });
      toast({ title: "Permissão atualizada" });
    } catch (e: any) {
      toast({ title: "Erro", description: e?.message ?? "Tente novamente", variant: "destructive" });
    }
  };

  const removeMember = async (membershipId: string) => {
    if (!companyId) return;
    try {
      debugLog("Settings", "membership delete", { companyId, membershipId });

      const { error } = await supabase
        .from("memberships")
        .delete()
        .eq("id", membershipId)
        .eq("company_id", companyId);

      if (error) throw error;

      qc.invalidateQueries({ queryKey: ["memberships"] });
      toast({ title: "Membro removido" });
    } catch (e: any) {
      toast({ title: "Erro", description: e?.message ?? "Tente novamente", variant: "destructive" });
    }
  };

  return (
    <div className="space-y-8">
      <Header title="Configurações" description="Empresa, membros e permissões" />

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Empresa</CardTitle>
          <CardDescription>Dados básicos da empresa ativa</CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col gap-3 md:flex-row md:items-end">
          <div className="flex-1 space-y-2">
            <div className="text-sm text-muted-foreground">Nome</div>
            <Input value={companyName} onChange={(e) => setCompanyName(e.target.value)} />
          </div>
          <Button onClick={saveCompany} disabled={savingCompany || !companyId}>
            {savingCompany ? "Salvando…" : "Salvar"}
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Membros</CardTitle>
          <CardDescription>Quem tem acesso a esta empresa</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          {membersQuery.isLoading ? (
            <div className="text-sm text-muted-foreground">Carregando…</div>
          ) : (membersQuery.data ?? []).length === 0 ? (
            <div className="text-sm text-muted-foreground">
              Nenhum dado ainda. Quando houver membros, aparecerão aqui.
            </div>
          ) : (
            (membersQuery.data ?? []).map((m) => {
              const p = profileById.get(m.user_id);
              return (
                <div key={m.id} className="flex flex-col gap-2 md:flex-row md:items-center md:justify-between rounded-lg border p-3">
                  <div>
                    <div className="font-medium">{p?.full_name ?? p?.email ?? m.user_id}</div>
                    <div className="text-sm text-muted-foreground">{p?.email ?? "—"}</div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Select
                      value={m.role}
                      onValueChange={(v) => updateMemberRole(m.id, v as Role)}
                      disabled={!canManageMembers}
                    >
                      <SelectTrigger className="w-40">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="owner">Owner</SelectItem>
                        <SelectItem value="admin">Admin</SelectItem>
                        <SelectItem value="member">Member</SelectItem>
                      </SelectContent>
                    </Select>
                    {canManageMembers && m.role !== "owner" ? (
                      <Button variant="destructive" size="sm" onClick={() => removeMember(m.id)}>
                        Remover
                      </Button>
                    ) : null}
                  </div>
                </div>
              );
            })
          )}
        </CardContent>
      </Card>
    </div>
  );
}
