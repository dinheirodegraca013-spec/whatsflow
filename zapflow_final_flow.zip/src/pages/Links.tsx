import { useMemo, useState } from "react";
import { Header } from "@/components/layout/Header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import {
  useCreateTrackingLink,
  useDeleteTrackingLink,
  useTrackingLinks,
  useUpdateTrackingLink,
} from "@/hooks/use-company-queries";

export default function Links() {
  const { toast } = useToast();
  const linksQuery = useTrackingLinks();
  const createLink = useCreateTrackingLink();
  const updateLink = useUpdateTrackingLink();
  const deleteLink = useDeleteTrackingLink();

  const [q, setQ] = useState("");
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ name: "", url: "", slug: "" });

  const rows = useMemo(() => {
    const all = linksQuery.data ?? [];
    const qq = q.trim().toLowerCase();
    if (!qq) return all;
    return all.filter((l) => {
      return (
        l.name.toLowerCase().includes(qq) ||
        l.url.toLowerCase().includes(qq) ||
        l.slug.toLowerCase().includes(qq)
      );
    });
  }, [linksQuery.data, q]);

  const onCreate = async () => {
    try {
      if (!form.name.trim() || !form.url.trim() || !form.slug.trim()) {
        toast({ title: "Preencha nome, URL e slug", variant: "destructive" });
        return;
      }
      await createLink.mutateAsync({
        name: form.name.trim(),
        url: form.url.trim(),
        slug: form.slug.trim(),
      });
      setForm({ name: "", url: "", slug: "" });
      setOpen(false);
      toast({ title: "Link criado" });
    } catch (e: any) {
      toast({ title: "Erro ao criar link", description: e?.message ?? "Tente novamente", variant: "destructive" });
    }
  };

  const onToggle = async (id: string, active: boolean) => {
    try {
      await updateLink.mutateAsync({ id, patch: { status: active ? "active" : "inactive" } });
      toast({ title: "Atualizado" });
    } catch (e: any) {
      toast({ title: "Erro", description: e?.message ?? "Tente novamente", variant: "destructive" });
    }
  };

  const onCopy = async (slug: string) => {
    try {
      await navigator.clipboard.writeText(slug);
      toast({ title: "Slug copiado" });
    } catch {
      toast({ title: "Não foi possível copiar", variant: "destructive" });
    }
  };

  const onDelete = async (id: string) => {
    try {
      await deleteLink.mutateAsync(id);
      toast({ title: "Removido" });
    } catch (e: any) {
      toast({ title: "Erro", description: e?.message ?? "Tente novamente", variant: "destructive" });
    }
  };

  return (
    <div className="space-y-8">
      <Header title="Tracking Links" description="Crie links rastreáveis e acompanhe resultados" />

      <Card>
        <CardContent className="p-4 flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Buscar por nome, URL ou slug…" />

          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button>Criar Link</Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Novo Tracking Link</DialogTitle>
              </DialogHeader>

              <div className="space-y-3">
                <div className="space-y-2">
                  <Label>Nome</Label>
                  <Input value={form.name} onChange={(e) => setForm((p) => ({ ...p, name: e.target.value }))} />
                </div>
                <div className="space-y-2">
                  <Label>URL destino</Label>
                  <Input value={form.url} onChange={(e) => setForm((p) => ({ ...p, url: e.target.value }))} />
                </div>
                <div className="space-y-2">
                  <Label>Slug</Label>
                  <Input value={form.slug} onChange={(e) => setForm((p) => ({ ...p, slug: e.target.value }))} />
                </div>
                <Button onClick={onCreate} disabled={createLink.isPending} className="w-full">
                  {createLink.isPending ? "Criando…" : "Criar"}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </CardContent>
      </Card>

      {linksQuery.isLoading ? (
        <div className="text-sm text-muted-foreground">Carregando…</div>
      ) : rows.length === 0 ? (
        <Card>
          <CardContent className="p-8 text-center text-sm text-muted-foreground">
            Nenhum dado ainda. Comece criando o primeiro link.
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {rows.map((l) => (
            <Card key={l.id} className={l.status !== "active" ? "opacity-70" : ""}>
              <CardHeader className="py-4">
                <CardTitle className="text-base flex items-center justify-between gap-2">
                  <span className="truncate">{l.name}</span>
                  <div className="flex items-center gap-3">
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <span>Ativo</span>
                      <Switch checked={l.status === "active"} onCheckedChange={(v) => onToggle(l.id, v)} />
                    </div>
                    <Button variant="destructive" size="sm" onClick={() => onDelete(l.id)}>
                      Excluir
                    </Button>
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent className="pb-4 space-y-2">
                <div className="text-sm text-muted-foreground break-all">{l.url}</div>
                <div className="flex items-center justify-between gap-2">
                  <div className="text-sm font-mono">{l.slug}</div>
                  <Button variant="secondary" size="sm" onClick={() => onCopy(l.slug)}>
                    Copiar slug
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
