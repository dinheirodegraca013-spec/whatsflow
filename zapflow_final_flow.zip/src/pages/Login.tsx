import { useEffect, useMemo, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Loader2 } from "lucide-react";
import { debugLog } from "@/lib/debug";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isSignUp, setIsSignUp] = useState(false);
  const [companyName, setCompanyName] = useState("");
  const [fullName, setFullName] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [info, setInfo] = useState("");
  const [pendingRedirect, setPendingRedirect] = useState(false);

  const navigate = useNavigate();
  const location = useLocation();
  const { user, signIn, signUp } = useAuth();

  const from = useMemo(() => (location.state as any)?.from?.pathname ?? "/dashboard", [location.state]);

  useEffect(() => {
    if (pendingRedirect && user) {
      debugLog("Login", "redirecting after user set", { to: from, userId: user.id });
      navigate(from, { replace: true });
      setPendingRedirect(false);
    }
  }, [pendingRedirect, user, from, navigate]);

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setInfo("");
    setLoading(true);

    try {
      if (isSignUp) {
        const { data, error: signUpError } = await signUp(email, password, {
          full_name: fullName,
          company_name: companyName,
        });

        if (signUpError) {
          setError((signUpError as any)?.message ?? "Erro ao criar conta.");
          return;
        }

        if (!data) {
          setInfo("Conta criada! Verifique seu e-mail para confirmar e depois faça login.");
          setIsSignUp(false);
          setPassword("");
          return;
        }

        setPendingRedirect(true);
      } else {
        const { error: signInError } = await signIn(email, password);
        if (signInError) {
          setError((signInError as any)?.message ?? "Erro ao entrar.");
          return;
        }
        setPendingRedirect(true);
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-primary/5 to-secondary/5">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl font-bold">
            {isSignUp ? "Criar Conta" : "Entrar"}
          </CardTitle>
          <CardDescription>
            {isSignUp ? "Crie sua conta para começar" : "Acesse sua conta"}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {user ? (
            <div className="space-y-3">
              <div className="text-sm text-muted-foreground">
                Você já está logado como <span className="font-medium">{user.email}</span>.
              </div>
              <div className="flex gap-2">
                <Button type="button" className="flex-1" onClick={() => navigate("/dashboard", { replace: true })}>
                  Ir para dashboard
                </Button>
                <Button type="button" variant="secondary" className="flex-1" onClick={() => navigate("/logout", { replace: true })}>
                  Sair
                </Button>
              </div>
              <div className="border-t pt-4" />
            </div>
          ) : null}

          <form onSubmit={onSubmit} className="space-y-4">
            {isSignUp ? (
              <>
                <div className="space-y-2">
                  <Label htmlFor="fullName">Nome Completo</Label>
                  <Input
                    id="fullName"
                    type="text"
                    placeholder="Seu nome completo"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="companyName">Nome da Empresa</Label>
                  <Input
                    id="companyName"
                    type="text"
                    placeholder="Ex: Minha Empresa"
                    value={companyName}
                    onChange={(e) => setCompanyName(e.target.value)}
                    required
                  />
                </div>
              </>
            ) : null}

            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                placeholder="seu@email.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="password">Senha</Label>
              <Input
                id="password"
                type="password"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>

            {error ? (
              <Alert variant="destructive">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            ) : null}

            {info ? (
              <Alert>
                <AlertDescription>{info}</AlertDescription>
              </Alert>
            ) : null}

            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
              {isSignUp ? "Criar Conta" : "Entrar"}
            </Button>
          </form>

          <div className="mt-4 text-center text-sm text-muted-foreground">
            {isSignUp ? "Já tem uma conta?" : "Ainda não tem conta?"}{" "}
            <button
              type="button"
              onClick={() => {
                setIsSignUp(!isSignUp);
                setError("");
                setInfo("");
              }}
              className="text-primary hover:underline"
            >
              {isSignUp ? "Entrar" : "Criar conta"}
            </button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
