import { useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { debugError, debugLog } from "@/lib/debug";

export default function Logout() {
  useEffect(() => {
    (async () => {
      try {
        debugLog("Logout", "signOut start");
        const { error } = await supabase.auth.signOut();
        if (error) debugError("Logout", "signOut error", error);
      } catch (e) {
        debugError("Logout", "signOut exception", e);
      } finally {
        // Force hard navigation to reset React state.
        window.location.replace("/login");
      }
    })();
  }, []);

  return (
    <div className="min-h-screen flex items-center justify-center text-sm text-muted-foreground">
      Saindo…
    </div>
  );
}
