import { useMemo, useState } from "react";
import { Header } from "@/components/layout/Header";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useDeleteLead, useLeads, useUpdateLead } from "@/hooks/use-company-queries";

export default function Contacts() {
  const { toast } = useToast();
  const leadsQuery = useLeads();
  const updateLead = useUpdateLead();
  const deleteLead = useDeleteLead();
  const [q, setQ] = useState("");

  const rows = useMemo(() => {
    const all = leadsQuery.data ?? [];
    const qq = q.trim().toLowerCase();
    if (!qq) return all;
    return all.filter((l) => {
      return (
        l.name.toLowerCase().includes(qq) ||
        (l.email ?? "").toLowerCase().includes(qq) ||
        (l.phone ?? "").toLowerCase().includes(qq)
      );
    });
  }, [leadsQuery.data, q]);

  const onMarkQualified = async (id: string) => {
    try {
      await updateLead.mutateAsync({ id, patch: { status: "qualified" } });
      toast({ title: "Atualizado" });
    } catch (e: any) {
      toast({ title: "Erro", description: e?.message ?? "Tente novamente", variant: "destructive" });
    }
  };

  const onDelete = async (id: string) => {
    try {
      await deleteLead.mutateAsync(id);
      toast({ title: "Removido" });
    } catch (e: any) {
      toast({ title: "Erro", description: e?.message ?? "Tente novamente", variant: "destructive" });
    }
  };

  return (
    <div className="space-y-8">
      <Header title="Contatos" description="Todos os leads/contatos do seu CRM" />

      <Card>
        <CardContent className="p-4 flex gap-3 items-center">
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Buscar por nome, email ou telefone…" />
        </CardContent>
      </Card>

      {leadsQuery.isLoading ? (
        <div className="text-sm text-muted-foreground">Carregando…</div>
      ) : rows.length === 0 ? (
        <Card>
          <CardContent className="p-8 text-center text-sm text-muted-foreground">
            Nenhum dado ainda. Comece criando o primeiro lead.
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {rows.map((l) => (
            <Card key={l.id}>
              <CardContent className="p-4 flex flex-col gap-2 md:flex-row md:items-center md:justify-between">
                <div>
                  <div className="font-medium">{l.name}</div>
                  <div className="text-sm text-muted-foreground">{l.email ?? "—"} • {l.phone ?? "—"}</div>
                </div>
                <div className="flex items-center gap-2">
                  <div className="text-sm text-muted-foreground capitalize">{l.status}</div>
                  <Button variant="secondary" size="sm" onClick={() => onMarkQualified(l.id)}>
                    Marcar qualificado
                  </Button>
                  <Button variant="destructive" size="sm" onClick={() => onDelete(l.id)}>
                    Excluir
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
