import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useCompany } from "@/contexts/CompanyContext";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Loader2 } from "lucide-react";
import { debugError, debugLog } from "@/lib/debug";

function slugify(value: string) {
  return value
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)+/g, "")
    .slice(0, 48);
}

export default function Onboarding() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { setCompany } = useCompany();

  const [companyName, setCompanyName] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (!user?.id) {
      setError("Você precisa estar logado.");
      return;
    }
    if (!companyName.trim()) {
      setError("Informe o nome da empresa.");
      return;
    }

    setLoading(true);
    try {
      const baseSlug = slugify(companyName.trim());
      let created = null as any;

      for (let attempt = 0; attempt < 5; attempt += 1) {
        const attemptSlug =
          attempt === 0 ? baseSlug : `${baseSlug}-${Math.floor(Math.random() * 1000)}`;

        debugLog("Onboarding", "create company attempt", {
          userId: user.id,
          attempt,
          slug: attemptSlug,
        });

        const res = await supabase
          .from("companies")
          .insert({ name: companyName.trim(), slug: attemptSlug })
          .select("id,name,slug,domain,logo_url,settings,created_at,updated_at")
          .single();

        if (!res.error) {
          created = res.data;
          break;
        }

        const code = (res.error as any)?.code;
        if (code !== "23505") throw res.error;
      }

      if (!created) {
        throw new Error("Não foi possível criar a empresa (slug em uso).");
      }

      const { error: membershipErr } = await supabase.from("memberships").insert({
        company_id: created.id,
        user_id: user.id,
        role: "owner",
        joined_at: new Date().toISOString(),
      });

      if (membershipErr) throw membershipErr;

      setCompany(created);

      debugLog("Onboarding", "create company done", { companyId: created.id });
      navigate("/dashboard", { replace: true });
    } catch (err) {
      debugError("Onboarding", "create company error", err);
      setError((err as any)?.message ?? "Erro ao criar empresa.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-primary/5 to-secondary/5">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl font-bold">Criar empresa</CardTitle>
          <CardDescription>Finalize seu cadastro criando sua empresa.</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={onSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="companyName">Nome da Empresa</Label>
              <Input
                id="companyName"
                value={companyName}
                onChange={(e) => setCompanyName(e.target.value)}
                placeholder="Ex: Minha Empresa"
                required
              />
            </div>

            {error ? (
              <Alert variant="destructive">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            ) : null}

            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
              Criar
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
