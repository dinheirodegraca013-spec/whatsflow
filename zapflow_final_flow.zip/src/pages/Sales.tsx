import { useMemo } from "react";
import { Header } from "@/components/layout/Header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useLeads } from "@/hooks/use-company-queries";

export default function Sales() {
  const leadsQuery = useLeads();

  const stats = useMemo(() => {
    const leads = leadsQuery.data ?? [];
    const won = leads.filter((l) => l.status === "won");
    const lost = leads.filter((l) => l.status === "lost");
    const pipeline = leads.filter((l) => !["won", "lost"].includes(l.status));
    const wonValue = won.reduce((s, l) => s + (l.value ?? 0), 0);
    const pipelineValue = pipeline.reduce((s, l) => s + (l.value ?? 0), 0);
    return {
      total: leads.length,
      won: won.length,
      lost: lost.length,
      pipeline: pipeline.length,
      wonValue,
      pipelineValue,
    };
  }, [leadsQuery.data]);

  return (
    <div className="space-y-8">
      <Header title="Vendas" description="Resumo do funil baseado nos leads" />

      {leadsQuery.isLoading ? (
        <div className="text-sm text-muted-foreground">Carregando…</div>
      ) : (leadsQuery.data ?? []).length === 0 ? (
        <Card>
          <CardContent className="p-8 text-center text-sm text-muted-foreground">
            Nenhum dado ainda. Comece criando o primeiro lead.
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Ganho</CardTitle>
            </CardHeader>
            <CardContent className="space-y-1">
              <div className="text-2xl font-bold">{stats.won}</div>
              <div className="text-sm text-muted-foreground">
                {stats.wonValue.toLocaleString("pt-BR", { style: "currency", currency: "BRL" })}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">Em andamento</CardTitle>
            </CardHeader>
            <CardContent className="space-y-1">
              <div className="text-2xl font-bold">{stats.pipeline}</div>
              <div className="text-sm text-muted-foreground">
                {stats.pipelineValue.toLocaleString("pt-BR", { style: "currency", currency: "BRL" })}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">Perdido</CardTitle>
            </CardHeader>
            <CardContent className="space-y-1">
              <div className="text-2xl font-bold">{stats.lost}</div>
              <div className="text-sm text-muted-foreground">de {stats.total} leads</div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
