import { useMemo, useState, useDeferredValue } from "react";
import { Header } from "@/components/layout/Header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import {
  useCreateLead,
  useDeleteLead,
  useLeads,
  useUpdateLead,
} from "@/hooks/use-company-queries";
import type { Tables } from "@/integrations/supabase/types";

type Lead = Tables<"leads">;

const STATUSES: { value: Lead["status"]; label: string }[] = [
  { value: "new", label: "Novo" },
  { value: "contacted", label: "Contatado" },
  { value: "qualified", label: "Qualificado" },
  { value: "proposal", label: "Proposta" },
  { value: "negotiation", label: "Negociação" },
  { value: "won", label: "Ganho" },
  { value: "lost", label: "Perdido" },
];

export default function CRM() {
  const { toast } = useToast();
  const leadsQuery = useLeads();
  const createLead = useCreateLead();
  const updateLead = useUpdateLead();
  const deleteLead = useDeleteLead();

  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<Lead["status"] | "all">("all");
  const deferredSearch = useDeferredValue(search);

  const [createOpen, setCreateOpen] = useState(false);
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    source: "",
    value: "",
    notes: "",
  });

  const leads = useMemo(() => {
    const all = leadsQuery.data ?? [];
    const q = deferredSearch.trim().toLowerCase();
    if (!q) return all;
    return all.filter((l) => {
      if (statusFilter !== "all" && l.status !== statusFilter) return false;
      if (!q) return true;
      return (
        l.name.toLowerCase().includes(q) ||
        (l.email ?? "").toLowerCase().includes(q) ||
        (l.phone ?? "").toLowerCase().includes(q) ||
        (l.source ?? "").toLowerCase().includes(q)
      );
    });
  }, [leadsQuery.data, deferredSearch, statusFilter]);

  const grouped = useMemo(() => {
    const map = new Map<Lead["status"], Lead[]>();
    for (const s of STATUSES) map.set(s.value, []);
    for (const l of leads) map.get(l.status)?.push(l);
    return map;
  }, [leads]);

  const onCreate = async () => {
    try {
      if (!form.name.trim()) {
        toast({ title: "Nome é obrigatório", variant: "destructive" });
        return;
      }
      const valueNum = form.value.trim() ? Number(form.value.replace(",", ".")) : null;

      await createLead.mutateAsync({
        name: form.name.trim(),
        email: form.email.trim() || null,
        phone: form.phone.trim() || null,
        source: form.source.trim() || null,
        notes: form.notes.trim() || null,
        value: valueNum && !Number.isNaN(valueNum) ? valueNum : null,
      });

      setCreateOpen(false);
      setForm({ name: "", email: "", phone: "", source: "", value: "", notes: "" });
      toast({ title: "Lead criado" });
    } catch (e: any) {
      toast({ title: "Erro ao criar lead", description: e?.message ?? "Tente novamente", variant: "destructive" });
    }
  };

  const onChangeStatus = async (id: string, status: Lead["status"]) => {
    try {
      await updateLead.mutateAsync({ id, patch: { status } });
      toast({ title: "Status atualizado" });
    } catch (e: any) {
      toast({ title: "Erro ao atualizar status", description: e?.message ?? "Tente novamente", variant: "destructive" });
    }
  };

  const onDelete = async (id: string) => {
    try {
      await deleteLead.mutateAsync(id);
      toast({ title: "Lead removido" });
    } catch (e: any) {
      toast({ title: "Erro ao remover lead", description: e?.message ?? "Tente novamente", variant: "destructive" });
    }
  };

  return (
    <div className="space-y-8">
      <Header title="CRM" description="Gerencie seus leads e pipeline" />

      <Card>
        <CardContent className="p-4 flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
          <div className="flex gap-3 flex-1">
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Buscar por nome, email, telefone ou origem…"
              className="max-w-lg"
            />
            <Select value={statusFilter} onValueChange={(v) => setStatusFilter(v as any)}>
              <SelectTrigger className="w-44">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos</SelectItem>
                {STATUSES.map((s) => (
                  <SelectItem key={s.value} value={s.value}>
                    {s.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <Dialog open={createOpen} onOpenChange={setCreateOpen}>
            <DialogTrigger asChild>
              <Button>Criar Lead</Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Novo Lead</DialogTitle>
              </DialogHeader>

              <div className="space-y-3">
                <div className="space-y-2">
                  <Label>Nome</Label>
                  <Input value={form.name} onChange={(e) => setForm((p) => ({ ...p, name: e.target.value }))} />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label>Email</Label>
                    <Input value={form.email} onChange={(e) => setForm((p) => ({ ...p, email: e.target.value }))} />
                  </div>
                  <div className="space-y-2">
                    <Label>Telefone</Label>
                    <Input value={form.phone} onChange={(e) => setForm((p) => ({ ...p, phone: e.target.value }))} />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label>Origem</Label>
                    <Input value={form.source} onChange={(e) => setForm((p) => ({ ...p, source: e.target.value }))} />
                  </div>
                  <div className="space-y-2">
                    <Label>Valor (R$)</Label>
                    <Input value={form.value} onChange={(e) => setForm((p) => ({ ...p, value: e.target.value }))} />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Notas</Label>
                  <Textarea value={form.notes} onChange={(e) => setForm((p) => ({ ...p, notes: e.target.value }))} />
                </div>

                <Button onClick={onCreate} disabled={createLead.isPending} className="w-full">
                  {createLead.isPending ? "Criando…" : "Criar"}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </CardContent>
      </Card>

      {leadsQuery.isLoading ? (
        <div className="text-sm text-muted-foreground">Carregando…</div>
      ) : leads.length === 0 ? (
        <Card>
          <CardContent className="p-8 text-center text-sm text-muted-foreground">
            Nenhum dado ainda. Comece criando o primeiro lead.
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4">
          {STATUSES.map((s) => {
            const items = grouped.get(s.value) ?? [];
            return (
              <Card key={s.value} className="h-fit">
                <CardHeader className="py-4">
                  <CardTitle className="text-base flex items-center justify-between">
                    <span>{s.label}</span>
                    <span className="text-sm text-muted-foreground">{items.length}</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {items.length === 0 ? (
                    <div className="text-xs text-muted-foreground">Nenhum lead neste status.</div>
                  ) : (
                    items.map((l) => (
                      <div key={l.id} className="rounded-lg border p-3 space-y-2">
                        <div className="flex items-start justify-between gap-2">
                          <div>
                            <div className="font-medium">{l.name}</div>
                            <div className="text-xs text-muted-foreground">
                              {(l.source ?? "Sem origem") + " • " + new Date(l.created_at).toLocaleDateString("pt-BR")}
                            </div>
                          </div>
                          <Button variant="ghost" size="sm" onClick={() => onDelete(l.id)}>
                            Remover
                          </Button>
                        </div>

                        <div className="text-sm text-muted-foreground">
                          {l.email ?? l.phone ?? "—"}
                        </div>

                        <div className="flex items-center justify-between gap-2">
                          <Select value={l.status} onValueChange={(v) => onChangeStatus(l.id, v as any)}>
                            <SelectTrigger className="w-40">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              {STATUSES.map((opt) => (
                                <SelectItem key={opt.value} value={opt.value}>
                                  {opt.label}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>

                          <div className="text-sm font-medium">
                            {(l.value ?? 0).toLocaleString("pt-BR", { style: "currency", currency: "BRL" })}
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
